import { sveltekit } from '@sveltejs/kit/vite';
import ProximaServer from './server/proximaServer.js';

let proximaServer;
const proximaServerConfig = {
	name: 'proximaServer',
	configureServer(server) {
		proximaServer = new ProximaServer(server.httpServer, '/api');
	}
}

/** @type {import('vite').UserConfig} */
const config = {
	plugins: [sveltekit(), proximaServerConfig],
	server: { hmr: { port: 5174 } }
};

export default config;
