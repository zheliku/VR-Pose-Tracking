# Proxima Web App

This is the source for the Proxima Web App.

**Please note** - if you make heavy modifications here, you may have trouble taking future Proxima updates.

## Setup

1. Install [Powershell](https://learn.microsoft.com/en-us/powershell/) 7+
2. Install [NodeJS](https://nodejs.org/) 22+
3. In this directoy, run `npm install`

## Build

1. Run `pwsh makestatic.ps1`
2. This will generate `build/web.proximastatic`. Copy it to Unity under `Proxima/Resources/Proxima/web.proximastatic`.

## Developer Iteration

For faster developer iteration, you can run Proxima in debug mode.

In Unity, go to `Project Settings > Player > Scripting Define Symbols` and add `PROXIMA_DEBUG`. Now go to the `Proxima Inspector` component in the editor and change `Connection Type` to `Debug`. Make sure to change it back when you're done!

In the web directory, run

```
npm run dev
```

This will start a local web server that hosts the Proxima web app. When in Debug mode, Proxima will connect to it instead of hosting its own web server. Now you can modify the web app and test the updates instantly.

## Project Layout

This is a [Svelte 5](https://svelte.dev/) app and uses [TailwindCSS](https://tailwindcss.com/) to for styling. Each page is a component:
- Inspector: `src/lib/components/inspectorPage.svelte`
- Logs: `src/lib/components/logsPage.svelte`
- Console: `src/lib/components/consolePage.svelte`

## Support

If you have questions, please reach out on [Discord](https://discord.gg/VM9cWJ9rjH).