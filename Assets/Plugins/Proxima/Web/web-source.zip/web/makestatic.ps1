# Build and zip
npm run build
compress-archive -Path build/* -DestinationPath web.zip -Force

# Make this unique to Proxima - add a byte at the beginning
$path = Resolve-Path ./web.zip
$bytes = [System.IO.File]::ReadAllBytes($path);
$newBytes = New-Object byte[] ($bytes.Length + 1)
$newBytes[0] = 0x79
[System.Array]::Copy($bytes, 0, $newBytes, 1, $bytes.Length)
[System.IO.File]::WriteAllBytes($path, $newBytes);

move web.zip build/web.proximastatic -Force