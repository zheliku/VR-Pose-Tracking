import { get, writable, type Readable } from "svelte/store";
import type { ConnectionInfo } from "./serializedTypes";
import sha256 from 'crypto-js/sha256';
import Base64 from 'crypto-js/enc-base64';

enum ProximaRequestType {
    Command = 0,
    StreamStart = 1,
    StreamStop = 2,
    List = 3,
    Select = 4
}

interface ProximaRequest {
    Id?: string;
    Type: ProximaRequestType;
    Cmd: string;
    Args: string[];
}

interface ProximaResponse {
    Id: string;
    Data: any;
    Error: string;
}

interface ProximaChannel {
    connect(): Promise<void>;
    disconnect(): void;
    send(data: string): void;
    onmessage: (evt: MessageEvent<any>) => void;
    onopen: () => void;
    onclose: () => void;
    onerror: (evt: Event) => void;
    readyState: number;
}

class ProximaWebSocketChannel implements ProximaChannel {
    private ws: WebSocket | null = null;

    public async connect() {
        const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
        let addr = protocol + '//' + window.location.host + (window.location.pathname || '/') + "api";
        console.log("Connect websocket: " + addr);
        this.ws = new WebSocket(addr);
        this.ws.onopen = () => this.onopen();
        this.ws.onmessage = (evt) => this.onmessage(evt);
        this.ws.onerror = (evt) => this.onerror(evt);
        this.ws.onclose = () => this.onclose();
    }

    public disconnect() {
        if (this.ws?.readyState === WebSocket.OPEN) {
            this.ws.close();
        }
    }

    public send(data: string) {
        if (this.ws?.readyState === WebSocket.OPEN) {
            this.ws.send(data);
        }
    }

    public onmessage: (evt: MessageEvent<any>) => void = () => { };
    public onopen: () => void = () => { };
    public onclose: () => void = () => { };
    public onerror: (evt: Event) => void = () => { };

    public get readyState(): number {
        return this.ws?.readyState ?? WebSocket.CLOSED;
    }
}

class ProximaBroadcastChannel implements ProximaChannel {
    private outBC: BroadcastChannel | null = null;
    private inBC: BroadcastChannel | null = null;

    connect(): Promise<void> {
        console.log("Connect broadcast channel.");

        window.addEventListener('pagehide', () => this.outBC?.postMessage('close'));

        return Promise.resolve().then(() => this.onopen());
    }

    disconnect(): void {
        console.log("Disconnect broadcast channel.");
        if (this.outBC) {
            this.outBC.postMessage('close');
        }

        this.reset();
        this.onclose();
    }

    private reset(): void {
        if (this.outBC) {
            this.outBC.close();
            this.outBC = null;
        }

        if (this.inBC) {
            this.inBC.close();
            this.inBC = null;
        }
    }

    private list() {
        // Read available connections from local storage.
        const jsonConnections = window.localStorage.getItem('proxima-connections');
        return JSON.parse(jsonConnections!) as ConnectionInfo[]
    }

    send(data: string): void {
        if (this.outBC) {
            this.outBC.postMessage(data);
            return;
        }

        const req = JSON.parse(data) as ProximaRequest;
        if (req.Type === ProximaRequestType.List) {
            const response = { Id: req.Id, Data: this.list(), Error: '' } as ProximaResponse;
            Promise.resolve().then(() => this.onmessage({ data: JSON.stringify(response) } as MessageEvent<any>));

        } else if (req.Type === ProximaRequestType.Select) {
            this.reset();
            const connections = this.list();
            const instance = connections.find(i => i.InstanceId === req.Cmd);
            if (instance) {
                this.outBC = new BroadcastChannel('proxima-' + instance.ConnectionId + '-in');
                this.inBC = new BroadcastChannel('proxima-' + instance.ConnectionId + '-out');

                this.inBC.onmessage = (evt) => {
                    if (evt.data === 'close') {
                        this.reset();
                        this.onclose();
                    } else {
                        this.onmessage(evt);
                    }
                };

                // Forward the select request to the server.
                this.outBC.postMessage(data);

            } else {
                const response = { Id: req.Id, Data: null, Error: 'Connection not found.' } as ProximaResponse;
                Promise.resolve().then(() => this.onmessage({ data: JSON.stringify(response) } as MessageEvent<any>));
            }
        }
    }

    onmessage: (evt: MessageEvent<any>) => void = () => { };
    onopen: () => void = () => { };
    onclose: () => void = () => { };
    onerror: (evt: Event) => void = () => { };

    public get readyState(): number {
        return WebSocket.OPEN;
    }
}

class ProximaApi  {
    private channel: ProximaChannel | null = null;
    private routes = new Map<string, (data: any, error: string) => boolean>();
    private nextId = 0;
    private started = false;

    private _instances = writable<ConnectionInfo[]>([]);
    public get instances(): Readable<ConnectionInfo[]> { return this._instances; }

    private _connected = writable<ConnectionInfo | undefined>();
    public get connected(): Readable<ConnectionInfo | undefined> { return this._connected; }

    private _error = writable<string>('');
    public get error(): Readable<string> { return this._error; }

    private _selected = writable<string>('');
    public get selected(): Readable<string> { return this._selected; }

    private _features = writable<string[]>([]);
    public get features(): Readable<string[]> { return this._features; }

    private _password = '';
    private _listing = false;
    private _selecting = false;

    public pollList = false;

    public autoConnect(password: string) {
        this._password = password;
        this._selected.set('ANY');
    }

    public start() {
        if (!this.started) {
            this.started = true;
            if (!this._password) {
                this.loadConnection();
            }

            this.connect();
        }
    }

    public disconnect() {
        if (this.channel?.readyState === WebSocket.OPEN) {
            this.clearConnection();
            this._selected.set('');
            this._password = '';
            this.channel.disconnect();
       }
    }

    private async connect() {
        try {
            if (window.localStorage.getItem('proxima-connections')) {
                this.channel = new ProximaBroadcastChannel();
            } else {
                this.channel = new ProximaWebSocketChannel();
            }

            this.channel.onopen = () => this.onOpen();
            this.channel.onmessage = (evt) => this.onMessage(evt);
            this.channel.onerror = (evt) => this.onError(evt);
            this.channel.onclose = () => this.onClose();
            await this.channel.connect();
        } catch (e: any) {
            console.error(e);
            this._connected.set(undefined);
            this._error.set(e.toString());
            this._instances.set([]);
            await new Promise<void>(resolve => setTimeout(resolve, 1000));
            await this.connect();
        }
    }

    private send(request: ProximaRequest, cb?: (data: any, error: string) => boolean) {
        if (this.channel?.readyState === WebSocket.OPEN) {
            if (!request.Id) {
                request.Id = this.nextId.toString();
                this.nextId++;
            }

            if (cb) {
                this.routes.set(request.Id, cb)
            } else {
                this.routes.delete(request.Id);
            }

            this.channel.send(JSON.stringify(request));
            return request.Id;
        }

        cb?.("", "Not connected");
        return "";
    }

    public async sendCommand(cmd: string, ...args: any[]): Promise<any> {
        if (!get(this._connected)) {
            throw new Error("Not connected");
        }

        return new Promise<any>((resolve, reject) => this.send({
            Type: ProximaRequestType.Command,
            Cmd: cmd,
            Args: args,
        }, (data, error) => {
            if (error) {
                reject(error);
            } else {
                resolve(data);
            }

            return false;
        }));
    }

    public sendCommandNoResponse(cmd: string, ...args: any[]) {
        this.send({
            Type: ProximaRequestType.Command,
            Cmd: cmd,
            Args: args
        });
    }

    public startStream(stream: string, args: string[], cb: (data: any, error: string) => any) {
        if (!get(this._connected)) {
            throw new Error("Not connected");
        }

        return this.send({
            Type: ProximaRequestType.StreamStart,
            Cmd: stream,
            Args: args,
        }, (data, error) => {
            cb(data, error);
            return true;
        });
    }

    public stopStream(stream: string, id: string) {
        if (!get(this._connected)) {
            return;
        }

        this.send({
            Id: id,
            Type: ProximaRequestType.StreamStop,
            Cmd: stream,
            Args: [],
        });
    }

    private onOpen() {
        console.log("Connection opened.");
        this._error.set('');
        this.list();
    }

    private list() {
        if (this.channel && !this._listing) {
            console.log("Requesting list of possible connections.");
            this._listing = true;
            this.send({
                Type: ProximaRequestType.List,
                Cmd: '',
                Args: []
            }, (data, error) => this.onList(data, error));
        }
    }

    private retryList() {
        if (this.channel?.readyState !== WebSocket.OPEN) {
            return;
        }

        if (this._selecting) {
            return;
        }

        if (this.pollList || (!get(this.connected) && (get(this._selected)))) {
            setTimeout(() => this.list(), 1000);
        }
    }

    private onList(data: any, error: string) {
        this._listing = false;

        if (error) {
            console.log("Failed to list possible connections: " + error);
            this._error.set(error);
            this.retryList();
            return false;
        }

        const instances = data as ConnectionInfo[];
        this._instances.set(instances);
        if (instances.length > 0) {
            this.retryList();

            if (get(this._selected) === 'ANY') {
                this._selected.set(instances[0].InstanceId);
            }

            const reconnect = instances.find(i => i.InstanceId === get(this._selected));
            if (!this._selecting && !get(this._connected) && reconnect) {
                this.select(reconnect, this._password);
            }
        } else if (this.channel?.readyState === WebSocket.OPEN) {
            console.log("No connections available.");
            this.retryList();
        }

        return false;
    }

    public select(instance: ConnectionInfo, password: string) {
        console.log("Selecting connection: " + instance.InstanceId);
        this._selected.set(instance.InstanceId);
        const hash = Base64.stringify(sha256(password + instance.ConnectionId));
        this._password = password;
        this._selecting = true;
        this.send({
            Type: ProximaRequestType.Select,
            Cmd: instance.InstanceId,
            Args: [hash]
        }, (data, error) => this.onSelect(instance.InstanceId, error));
    }

    private onSelect(instanceId: string, error: string) {
        this._selecting = false;

        if (error) {
            console.log("Failed to select connection: " + error + ".");
            this._selected.set('');
            this._password = '';
            this._error.set(error);
            this.retryList();
        } else {
            console.log("Selected connection open.");
            this._connected.set(get(this._instances).find(i => i.InstanceId === instanceId));
            this._instances.set([]);
            this.saveConnection();
            this._error.set('');
            this.getFeatures();
        }

        return false;
    }

    private async getFeatures() {
        try {
            const features = await this.sendCommand('GetInstalledFeatures');
            console.log("Installed features: " + features);
            this._features.set(features);
        } catch (e) {
            console.log("Failed to get installed features: " + e);
        }
    }

    private saveConnection() {
        window.sessionStorage.setItem('proxima-instance', get(this._selected));
        window.sessionStorage.setItem('proxima-password', this._password);
    }

    private loadConnection() {
        const instance = window.sessionStorage.getItem('proxima-instance');
        const password = window.sessionStorage.getItem('proxima-password');
        if (instance && password) {
            this._selected.set(instance);
            this._password = password;
        }
    }

    private clearConnection() {
        window.sessionStorage.removeItem('proxima-instance');
        window.sessionStorage.removeItem('proxima-password');
    }

    private onMessage(evt: MessageEvent) {
        let response: ProximaResponse;
        // console.log(evt.data);

        try {
            response = JSON.parse(evt.data);
        } catch (e: any) {
            console.error("Failed to parse response: " + e);
            return;
        }

        var route = this.routes.get(response.Id);
        if (route) {
            if (!route(response.Data, response.Error)) {
                this.routes.delete(response.Id);
            }
        }
    }

    private onError(evt: Event) {
        console.log("Connection Error");
        this._error.set('Failed to connect to the Proxima Server.');
        this._instances.set([]);
    }

    private async onClose() {
        this._selecting = false;
        this._listing = false;
        this._connected.set(undefined);
        console.log("Connection closed.")
        await new Promise<void>(resolve => setTimeout(resolve, 1000));
        this.connect();
    }
}

const proxima = new ProximaApi();
export default proxima;