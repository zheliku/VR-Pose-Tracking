<script lang="ts">
    import { onDestroy } from "svelte";
    import ObjectValue from "./objectValue.svelte";

    let { type, value = $bindable(), enabled, readonly, onChange }: {
        type: string;
        value: any;
        enabled: boolean;
        readonly: boolean,
        onChange: (v: any) => void } = $props();

    let input1 = $state<HTMLInputElement>();
    let input2 = $state<HTMLInputElement>();
    let input3 = $state<HTMLInputElement>();
    let input4 = $state<HTMLInputElement>();

    $effect(() => {
        if (input1) {
            input1.disabled = !enabled || (readonly && input1.type !== "text");
            input1.readOnly = readonly;
            input1.addEventListener('input', onInput);
        }
    });

    $effect(() => {
        if (input2) {
            input2.disabled = !enabled || (readonly && input2.type !== "text");
            input2.readOnly = readonly;
            input2.addEventListener('input', onInput);
        }
    });

    $effect(() => {
        if (input3) {
            input3.disabled = !enabled || (readonly && input3.type !== "text");
            input3.readOnly = readonly;
            input3.addEventListener('input', onInput);
        }
    });

    $effect(() => {
        if (input4) {
            input4.disabled = !enabled || (readonly && input4.type !== "text");
            input4.readOnly = readonly;
            input4.addEventListener('input', onInput);
        }
    });

    function onInput() {
        var v1 = input1 ? (input1.type == "checkbox" ? input1.checked : input1.value) : '';
        var v2 = input2?.value ?? '';
        var v3 = input3?.value ?? '';
        var v4 = input4?.value ?? '';
        if (Array.isArray(value)) {
            value = [v1, v2, v3, v4]
        } else if (type === 'Color') {
            var alpha = input2!.valueAsNumber.toString(16);
            if (alpha.length == 1) alpha = '0' + alpha;
            value = v1 + alpha;
        } else {
            value = v1;
        }

        onChange?.(value);
    }

    let draggingInput: HTMLInputElement | null = null;
    let lastTouch = 0;

    function onDragStart(e: Event) {
        if (enabled && !readonly) {
            draggingInput = (e.target as HTMLElement).nextElementSibling as HTMLInputElement;
            window.addEventListener('mouseup', onDragEnd);
            window.addEventListener('touchend', onDragEnd);
            window.addEventListener('mousemove', onMouseMove);
            window.addEventListener('touchmove', onTouchMove);
        }
    }

    function onDragEnd() {
        draggingInput = null;
        lastTouch = 0;
        window.removeEventListener('mouseup', onDragEnd);
        window.removeEventListener('touchend', onDragEnd);
        window.removeEventListener('mousemove', onMouseMove);
        window.removeEventListener('touchmove', onTouchMove);
    }

    function onDragMove(dx: number) {
        if (draggingInput) {
            let newValue: string;
            if (type === "SByte" || type === "Int16" || type === "Int32" || type == "Int64") {
                newValue = (Number.parseInt(draggingInput.value) + dx).toFixed(0);
            } else if (type === "Byte" || type === "UInt16" || type === "UInt32" || type == "UInt64") {
                newValue = Math.max(0, Number.parseInt(draggingInput.value) + dx).toFixed(0);
            } else {
                newValue = (Number.parseFloat(draggingInput.value) + 0.1 * dx).toFixed(4);
            }

            draggingInput.value = newValue;
            onInput();
        }
    }

    function onMouseMove(e: MouseEvent) {
        onDragMove(e.movementX);
    }

    function onTouchMove(e: TouchEvent) {
        if (e.touches.length === 1) {
            e.preventDefault();
            if (lastTouch !== 0) {
                const dx = e.touches[0].screenX - lastTouch;
                onDragMove(dx);
            }

            lastTouch = e.touches[0].screenX;
        }
    }

    onDestroy(onDragEnd);
</script>

{#if type === 'Vector2Int' || type === 'Vector2'}
    <div class="flex grow gap-2">
        <button class="cursor-ew-resize select-none" tabindex="-1" onmousedown={onDragStart} ontouchstart={onDragStart}>X</button>
        <input bind:this={input1} type="text" value="{value[0]}" class="grow">
        <button class="cursor-ew-resize select-none" tabindex="-1" onmousedown={onDragStart} ontouchstart={onDragStart}>Y</button>
        <input bind:this={input2} type="text" value="{value[1]}" class="grow">
    </div>
{:else if type === 'Vector3Int' || type === 'Vector3' || type === 'Quaternion'}
    <div class="flex grow gap-2">
        <button class="cursor-ew-resize select-none" tabindex="-1" onmousedown={onDragStart} ontouchstart={onDragStart}>X</button>
        <input bind:this={input1} type="text" value="{value[0]}" class="grow">
        <button class="cursor-ew-resize select-none" tabindex="-1" onmousedown={onDragStart} ontouchstart={onDragStart}>Y</button>
        <input bind:this={input2} type="text" value="{value[1]}" class="grow">
        <button class="cursor-ew-resize select-none" tabindex="-1" onmousedown={onDragStart} ontouchstart={onDragStart}>Z</button>
        <input bind:this={input3} type="text" value="{value[2]}" class="grow">
    </div>
{:else if type === 'Vector4' || type === 'Rect' || type === 'RectInt'}
    <div class="flex grow gap-2">
        <button class="cursor-ew-resize select-none" tabindex="-1" onmousedown={onDragStart} ontouchstart={onDragStart}>X</button>
        <input bind:this={input1} type="text" value="{value[0]}" class="grow">
        <button class="cursor-ew-resize select-none" tabindex="-1" onmousedown={onDragStart} ontouchstart={onDragStart}>Y</button>
        <input bind:this={input2} type="text" value="{value[1]}" class="grow">
        <button class="cursor-ew-resize select-none" tabindex="-1" onmousedown={onDragStart} ontouchstart={onDragStart}>Z</button>
        <input bind:this={input3} type="text" value="{value[2]}" class="grow">
        <button class="cursor-ew-resize select-none" tabindex="-1" onmousedown={onDragStart} ontouchstart={onDragStart}>W</button>
        <input bind:this={input4} type="text" value="{value[3]}" class="grow">
    </div>
{:else if type === "Single" || type === "Double"}
    <button class="absolute w-1/2 left-[-50%] h-full cursor-ew-resize select-none" aria-label="drag" onmousedown={onDragStart} ontouchstart={onDragStart}></button>
    <input bind:this={input1} class="grow" type="text" {value}>
{:else if type === "Boolean"}
    <input bind:this={input1} type="checkbox" checked={value}>
{:else if type === "SByte" || type === "Int16" || type === "Int32" || type === "Int64"}
    <button class="absolute w-1/2 left-[-50%] h-full cursor-ew-resize select-none" aria-label="drag" onmousedown={onDragStart} ontouchstart={onDragStart}></button>
    <input bind:this={input1} class="grow" type="text" {value}>
{:else if type === "Byte" || type === "UInt16" || type === "UInt32" || type === "UInt64"}
    <button class="absolute w-1/2 left-[-50%] h-full cursor-ew-resize select-none" aria-label="drag" onmousedown={onDragStart} ontouchstart={onDragStart}></button>
    <input bind:this={input1} class="grow" type="text" min="0" {value}>
{:else if type === "String"}
    <input bind:this={input1} class="grow" value={value || ""}>
{:else if type === 'Bounds' || type === 'BoundsInt'}
    <div class="flex grow flex-col">
        <div class="flex gap-2">
            <button class="cursor-ew-resize select-none" tabindex="-1" onmousedown={onDragStart} ontouchstart={onDragStart}>X</button>
            <input bind:this={input1} type="text" value="{value[0]}" class="grow">
            <button class="cursor-ew-resize select-none" tabindex="-1" onmousedown={onDragStart} ontouchstart={onDragStart}>Y</button>
            <input bind:this={input2} type="text" value="{value[1]}" class="grow">
            <button class="cursor-ew-resize select-none" tabindex="-1" onmousedown={onDragStart} ontouchstart={onDragStart}>Z</button>
            <input bind:this={input3} type="text" value="{value[2]}" class="grow">
        </div>
        <div class="flex gap-2">
            <button class="cursor-ew-resize select-none" tabindex="-1" onmousedown={onDragStart} ontouchstart={onDragStart}>W</button>
            <input bind:this={input1} type="text" value="{value[3]}" class="grow">
            <button class="cursor-ew-resize select-none" tabindex="-1" onmousedown={onDragStart} ontouchstart={onDragStart}>H</button>
            <input bind:this={input2} type="text" value="{value[4]}" class="grow">
            <button class="cursor-ew-resize select-none" tabindex="-1" onmousedown={onDragStart} ontouchstart={onDragStart}>D</button>
            <input bind:this={input3} type="text" value="{value[5]}" class="grow">
        </div>
    </div>
{:else if type === "Color"}
    <div class="flex flex-col grow">
        <input bind:this={input1} class="grow" type="color" value="{value.substring(0, 7)}">
        <div class="flex gap-2 grow">
            A <input bind:this={input2} class="grow" type="range" min="0" max="255" value="{parseInt(value.substring(7), 16)}">
        </div>
    </div>
{:else if type.startsWith("Object")}
    <ObjectValue type={type} value={value} {enabled} />
{:else}
    <div class="grow italic">Not Supported</div>
{/if}

<style>
    input {
        background-color: #222;
        border-radius: 5px;
        padding-left: 5px;
        min-width: 0;
        width: 100%;
    }

    input:disabled {
        background-color: #333;
        color: #888;
    }

    input[type=checkbox] {
        width: 15px;
        height: 15px;
        margin-top: 2px;
    }
</style>