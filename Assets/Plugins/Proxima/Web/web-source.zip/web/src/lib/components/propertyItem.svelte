<script lang="ts">
	import proxima from "$lib/api/proxima";
	import PrettyName from "$lib/util/prettyName";
	import type { PropertyInfo } from "$lib/api/serializedTypes";
    import BasicValue from "./basicValue.svelte";
    import EnumValue from "./enumValue.svelte";
    import FlagValue from "./flagValue.svelte";
    import ArrayValue from "./arrayValue.svelte";
    import { serialize, splitEnumType } from "$lib/api/serialization";
    import LayerMaskValue from "./layerMaskValue.svelte";
    import { scaleLinked } from "$lib/util/store";
    import SerializedValue from "./serializedValue.svelte";

    let {
        componentId,
        property = $bindable(),
        pathPrefix = "",
        showName = true,
        enabled,
        readonly
    }: {
        componentId: number;
        property: PropertyInfo;
        pathPrefix?: string;
        showName?: boolean;
        enabled: boolean;
        readonly: boolean;
    } = $props();

    let name = $derived(PrettyName(property.Name));

    let changePromise = Promise.resolve();

    function onChange(v: any) {
        if (property.Name === "localScale" && property.Type === "Vector3" && $scaleLinked) {
            let [x, y, z] = v.map((f: any) => +f);

            if (x === 0 || y === 0 || z === 0 || isNaN(x) || isNaN(y) || isNaN(z)) {
                return;
            }

            const [px, py, pz] = property.Value;

            const format = (f: number) => parseFloat(f.toFixed(4)).toString();

            if (x !== px) {
                y = format(y * x / px);
                z = format(z * x / px);
            }
            else if (y !== py) {
                x = format(x * y / py);
                z = format(z * y / py);
            }
            else if (z !== pz) {
                x = format(x * z / pz);
                y = format(y * z / pz);
            }

            // svelte-ignore ownership_invalid_mutation
            property.Value = [x, y, z];
        } else {
            // svelte-ignore ownership_invalid_mutation
            property.Value = v;
        }

        const value = serialize(property.Type, property.Value);
        changePromise = changePromise.then(() => sendValue(value));
    }

    async function sendValue(v: any) {
        proxima.sendCommandNoResponse('SetProperty', componentId, pathPrefix + property.Name, v);
    }
</script>

<div class="flex grow">
    {#if property.Type.startsWith('Array')}
        <ArrayValue {componentId} {name} items={property.Children || []} path={pathPrefix + property.Name} {enabled} {readonly} />
    {:else if property.Children !== undefined}
        <SerializedValue {componentId} {name} type={property.Type} value={property.Value} childPathPrefix={pathPrefix + property.Name + '.'} children={property.Children} {enabled} {readonly} />
    {:else}
        {#if showName}
            <div class="w-1/3 text-ellipsis overflow-clip whitespace-nowrap shrink-0">{name}</div>
        {/if}
        <div class="flex grow relative">
            {#if property.Type.startsWith('Enum')}
                <EnumValue type={property.Type} value={property.Value} {enabled} {readonly} {onChange} />
            {:else if property.Type.startsWith('Flags')}
                <FlagValue options={splitEnumType(property.Type)} value={property.Value} {enabled} {readonly} {onChange} />
            {:else if property.Type.startsWith('LayerMask')}
                <LayerMaskValue value={property.Value} {enabled} {readonly} {onChange} />
            {:else}
                {#if property.Name === "localScale" && property.Type === "Vector3"}
                    <button class="absolute left-[-30px] top-[2px] select-none" tabindex="-1"
                        disabled={!enabled || readonly} onclick={() => $scaleLinked = !$scaleLinked}>
                        <img src="{$scaleLinked ? './icons/linked.png' : './icons/unlinked.png'}" alt=""/>
                    </button>
                {/if}
                <BasicValue type={property.Type} value={property.Value} {enabled} {readonly} {onChange} />
            {/if}
        </div>
    {/if}
</div>