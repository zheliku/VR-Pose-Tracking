<script lang="ts">
    import { onMount } from "svelte";
    import type { DataPoint, Metric } from "./metric";
    import type CircularBuffer from "$lib/util/circularBuffer";

    let {
        metric,
        timeRange,
        height
    }: {
        metric: Metric;
        timeRange: number;
        height: number;
    } = $props();

    let availableWidth = $state(0);
    let svg: SVGElement;
    let counter = $state(0);

    onMount(() => {
        window.addEventListener('resize', onResize);
        onResize();

        const interval = setInterval(() => {
            counter += 1;
        }, 10);

        return () => {
            window.removeEventListener('resize', onResize);
            clearInterval(interval);
        };
    });

    function onResize() {
        availableWidth = svg.clientWidth;
    }

    function chartToString(data: CircularBuffer<DataPoint>, max: number, min: number, timeRange: number, width: number, counter: number) {
        if (data.length === 0 || width === undefined) {
            return "";
        }

        if (max === min) {
            max += min * 2;
            min -= min * 2;
        }

        let scale = (max - min) / height;

        const timeScale = width / (timeRange * 1000);
        const now = new Date().getTime();

        let minX = width;
        let maxX = 0;

        let chartString = "";
        for (let i = 0; i < data.length; i++) {
            const point = data.get(i);
            const time = now - point.time;
            let xPos = width - (time * timeScale);
            if (xPos >= 0) {

                // Avoid stutter at the edges
                if (xPos < 8)
                {
                    xPos = 0;
                }

                if (xPos > width - 8)
                {
                    xPos = width;
                }

                chartString += xPos + "," + (height - ((point.value - min) / scale)) + " ";
                minX = Math.min(minX, xPos);
                maxX = Math.max(maxX, xPos);
            }
        }

        const result = `${minX},${height} ${chartString} ${maxX},${height}`;
        return result;
    }

    function averageLineString(average: number, length: number, max: number, min: number) {
        if (max === min) {
            max += min * 2;
            min -= min * 2;
        }

        let scale = (max - min) / height;
        let ave = (height - ((average - min) / scale));
        return "0," + ave + " "  + length * 27 + "," + ave;
    }

    let dataString = $derived(chartToString(metric.data, metric.max, metric.min, timeRange, availableWidth, counter));
    let averageString = $derived(averageLineString(metric.average, availableWidth, metric.max, metric.min));
</script>

<svg bind:this={svg} class="w-full">
    <!-- x axis -->
    <line x1="0" x2={availableWidth} y1="120" y2="120" />

    <!-- y axis -->
    <line x1="0" x2="0" y1="0" y2="120" />
    <polyline points={dataString} />
    <polyline style="stroke: rgb(212,120,35)" points={averageString} />
</svg>

<style>
    line, polyline {
        stroke-width: 2;
        fill: rgb(30,58,138);
        stroke: rgb(59,130,246);
    }
</style>