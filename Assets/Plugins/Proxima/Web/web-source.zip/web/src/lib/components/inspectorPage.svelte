<script lang="ts">
    import type { GameObjectInfo } from "$lib/api/serializedTypes";
    import Hierarchy from "$lib/components/hierarchy.svelte";
    import Inspector from "$lib/components/inspector.svelte";
    import { hierarchyWidth } from "$lib/util/store";
    import { onMount } from "svelte";

    let selected = $state<GameObjectInfo | undefined>(undefined);
    let hierarchyDiv: HTMLDivElement;
    let lastTouch = $state(0);

    function onDragStart() {
        window.addEventListener("mousemove", onMouseMove);
        window.addEventListener("touchmove", onTouchMove);
        window.addEventListener("mouseup", onDragEnd);
        window.addEventListener("touchend", onDragEnd);
        $hierarchyWidth = hierarchyDiv.getBoundingClientRect().width;
    }

    function onDragMove(dx: number) {
        $hierarchyWidth += dx;
    }

    function onMouseMove(e: MouseEvent) {
        onDragMove(e.movementX);
    }

    function onTouchMove(e: TouchEvent) {
        if (e.touches.length === 1) {
            e.preventDefault();
            if (lastTouch !== 0) {
                const dx = e.touches[0].screenX - lastTouch;
                onDragMove(dx);
            }

            lastTouch = e.touches[0].screenX;
        }
    }

    function onDragEnd() {
        window.removeEventListener("mousemove", onMouseMove);
        window.removeEventListener("touchmove", onTouchMove);
        window.removeEventListener("mouseup", onDragEnd);
        window.removeEventListener("touchend", onDragEnd);
    }

    // Workaround 'window not defined' in onDestroy
    onMount(() => () => onDragEnd());
</script>

<div bind:this={hierarchyDiv} class="shrink-0" style="width: {$hierarchyWidth ? $hierarchyWidth + "px" : "33%"}">
    <Hierarchy bind:selected />
</div>
<div class="h-full w-[2px] bg-black relative shrink-0">
    <!-- svelte-ignore a11y_consider_explicit_label -->
    <button class="absolute left-[-5px] w-[calc(100%+10px)] top-0 bottom-0 cursor-ew-resize" onmousedown={onDragStart} ontouchstart={onDragStart}></button>
</div>
<Inspector bind:selected />