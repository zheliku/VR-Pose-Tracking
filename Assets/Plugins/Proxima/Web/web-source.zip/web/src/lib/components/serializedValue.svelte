<script lang="ts">
    import type { PropertyInfo } from "$lib/api/serializedTypes";
    import ObjectValue from "./objectValue.svelte";
    import PropertyItem from "./propertyItem.svelte";

    let {
        componentId,
        name,
        type,
        value,
        childPathPrefix,
        children,
        enabled,
        readonly
    }: {
        componentId: number;
        name: string;
        type: string;
        value: any;
        childPathPrefix: string;
        children: PropertyInfo[];
        enabled: boolean;
        readonly: boolean;
    } = $props();

    let expanded = $state(false);

    function toggleExpand() {
        expanded = !expanded;
    }
</script>

<div class="flex w-full flex-col gap-2">
    <div class="flex grow">
        <button class="flex w-full" onclick={toggleExpand}>
            <div class="flex gap-1 w-1/3 items-center">
                <div class="w-[15px] text-center text-xs outline-none shrink-0">
                    <img src="./icons/arrow.png" class:rotate-90={expanded} alt="">
                </div>
                <div class="text-ellipsis overflow-clip whitespace-nowrap shrink-0 font-bold text-left">{name}</div>
            </div>
            {#if type.startsWith("Object")}
                <ObjectValue {type} {value} {enabled} />
            {/if}
        </button>
    </div>
    {#if expanded && children.length > 0}
        <div class="flex flex-col gap-1 pl-5">
            {#each children as child}
                <PropertyItem {componentId} property={child} pathPrefix={childPathPrefix} {enabled} {readonly} />
            {/each}
        </div>
    {/if}
</div>