<script lang="ts">
    import proxima from "$lib/api/proxima";
	import type { GameObjectInfo } from "$lib/api/serializedTypes";
    import { expandedGameObjects } from "$lib/util/store";
    import GameObjectItem from './gameObjectItem.svelte';    

    let {
        selected = $bindable(),
        gois,
        gameObject,
        tree,
        parentActive = true,
        onkeydown,
    } : {
        selected: GameObjectInfo | undefined,
        gois: GameObjectInfo[],
        gameObject: GameObjectInfo,
        tree: boolean,
        parentActive?: boolean,
        onkeydown: (e: KeyboardEvent) => void
    } = $props();

    let children = $derived(gois.filter(go => go.Parent === gameObject.Id));
    let expanded = $derived($expandedGameObjects.has(gameObject.Id));
    const connected = proxima.connected;

    function toggleExpand() {
        if (expanded) {
            $expandedGameObjects.delete(gameObject.Id);
        } else {
            $expandedGameObjects.add(gameObject.Id);
        }

        $expandedGameObjects = $expandedGameObjects;
    }

    function handleKeyDown(e: KeyboardEvent) {
        e.preventDefault();
        onkeydown?.(e);
    }
</script>

<div id="go-item-{gameObject.Id}" class="flex w-full select-none mb-[-3px]"
    style="padding-left: {tree ? gameObject.Depth * 20 + 15 : 0}px; border-top: 3px solid transparent; border-bottom: 3px solid transparent;">

    <div class="flex w-full" class:selected={selected?.Id === gameObject.Id}>
        <button class="w-[20px] text-center text-xs outline-none shrink-0" onclick={toggleExpand} onkeydown={handleKeyDown}>
            {#if gameObject.ChildCount > 0 && tree}
                <img src="./icons/arrow.png" class:rotate-90={expanded} alt="">
            {/if}
        </button>
        <button class="grow text-start flex items-center gap-1 outline-none {selected?.Id !== gameObject.Id ? "hover:bg-[#444]" : ''}" onclick={() => selected = gameObject} disabled={!$connected} onkeydown={handleKeyDown}>
            <img src="./icons/d_GameObject_Icon.png" class="w-[15px]" alt="">
            <span class="whitespace-nowrap overflow-clip text-ellipsis" class:inactive={!parentActive || !gameObject.ActiveSelf}>{gameObject.Name}</span>
        </button>
    </div>
</div>

{#if tree && expanded}
    {#each children as child}
        <GameObjectItem bind:selected {gois} gameObject={child} {tree} parentActive={parentActive && gameObject.ActiveSelf} {onkeydown} />
    {/each}
{/if}

<style>
    .selected {
        background-color: #234A6C;
    }

    .inactive {
        color: #666;
    }
</style>