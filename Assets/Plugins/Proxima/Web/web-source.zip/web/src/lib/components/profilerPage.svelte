<script lang="ts">
    import { onDestroy } from "svelte";
    import type { ProfilerRecorderInfo, ProfilerDataInfo } from "$lib/api/serializedTypes";
    import proxima from "$lib/api/proxima";
    import DropDown from "$lib/components/dropDown.svelte";
    import type { DataPoint, Metric } from "./metric";
    import ProfilerMetric from "./profilerMetric.svelte";
    import CirclularBuffer from "$lib/util/circularBuffer";

    let currentCategory = $state("Memory");
    let categories = $state<string[]>([])
    let paused = $state(false);
    let showZeros = $state(false);
    let streamId = $state('');
    let timeRange = $state(30);
    let maxTime = $state(60);
    let wrongVersion = $state(false);
    let displayedMetrics = $state<Metric[]>([]);

    const connected = proxima.connected;

    $effect(() => {
        if ($connected) {
            onConnected();
        } else {
            onDisconnected();
        }
    });

    onDestroy(() => {
        onPause();
    });

    async function onConnected() {
        if (!paused) {
            getCategories();
            onResume();
        }
    }

    function onDisconnected() {
        streamId = '';
    }

    function onPause() {
        paused = true;
        stopStream();
    }

    function onResume() {
        paused = false;
        startStream(currentCategory);
    }

    function togglePause() {
        if (paused) {
            onResume();
        } else {
            onPause();
        }
    }

    function changeCategory(category: string) {
        startStream(category);
    }

    async function startStream(category: string) {
        stopStream();

        if ($connected) {
            try {
                const recorders = await proxima.sendCommand('GetRecorders', category)
                createDisplayMetrics(recorders);
            } catch (e) {
                console.error(e);
                return;
            }

            streamId = proxima.startStream('ProfilerStream', [category], (data: any, error: string) => {
                if (error) {
                    console.error(error); // TODO: display error on page
                    return;
                }

                addDataPoint(data);
            });
        }
    }

    function stopStream() {
        if ($connected && streamId) {
            proxima.stopStream('ProfilerStream', streamId);
            streamId = '';
        }
    }

    function addDataPoint(dataInfo: ProfilerDataInfo) {
        for (let i = 0; i < displayedMetrics.length; i++) {
            updateMetric(displayedMetrics[i], dataInfo.TimeStamp, dataInfo.Data[i]);
        }

        // Trigger reactivity
        displayedMetrics = displayedMetrics;
    }

    function updateMetric(metric: Metric, time: number, value: number) {
        metric.data.push({ time, value });

        let max: number | undefined = undefined;
        let min: number | undefined = undefined;
        let totalValues = 0;
        let average = 0;
        const now = new Date().getTime();

        for (let i = 0; i < metric.data.length; i++) {
            const point = metric.data.get(i);
            if (now - point.time > timeRange * 1000) {
                continue;
            }

            const value = point.value;

            // For some reasons we're getting very large negative time values
            // Just ignore negative values.
            if (value >= 0) {
                average += value;
                totalValues++;

                if (min === undefined || value < min) {
                    min = value;
                }

                if (max === undefined || value > max) {
                    max = value;
                }
            } else {
                point.value = 0;
            }
        }

        if (totalValues > 0) {
            average /= totalValues;
        }

        metric.max = max || 0;
        metric.min = min || 0;
        metric.average = average;
    }

    async function getCategories() {
        try {
            const data = await proxima.sendCommand('GetCategories');
            categories = data as string[];

        } catch (e) {
            console.error(e);
        }
    }

    function createDisplayMetrics(recorders: ProfilerRecorderInfo[]) {
        displayedMetrics = Array<Metric>(recorders.length);

        for (let i = 0; i < displayedMetrics.length; i++) {
            displayedMetrics[i] = {
                name: recorders[i].Name,
                units: recorders[i].Units,
                min: 0,
                max: 0,
                average: 0,
                data: new CirclularBuffer<DataPoint>(maxTime * 100)
            };
        }
    }

    function onClear() {
        for (const metric of displayedMetrics) {
            metric.min = 0;
            metric.max = 0;
            metric.average = 0;
            metric.data.clear();
        }
    }

    function toggleHideZeros() {
        showZeros = !showZeros;
    }
</script>

<div class="flex flex-col grow text-sm">
    {#if wrongVersion}
        <div style="padding-top: 10px; padding-left:20px; font-size: 20px">A Unity version of 2020.2 or higher is required for this feature.</div>
    {:else}
        <div class="flex border-[#191919] border-b-2" >
            <DropDown>
                {#snippet button()}
                    <div class="border-r-2 border-[#191919] p-1 pl-3 pr-3 flex gap-3 justify-between shrink-0 w-[250px]">
                        {currentCategory}
                        <img class="rotate-90" src="./icons/arrow.png" alt="" />
                    </div>
                {/snippet}

                {#snippet options()}
                    <div class="flex flex-col bg-[#2D2D2D] border-b-2 border-t-2 border-[#191919]">
                        <div class="overflow-y-auto w-[250px] max-h-[50vh]">
                            {#each categories as category}
                                <button class="hover:bg-[#444] w-full p-2 text-left border-[#191919] border-2 border-b-0 whitespace-nowrap" onclick={() => changeCategory(category)}>{category}</button>
                            {/each}
                        </div>
                    </div>
                {/snippet}
            </DropDown>
            <button class="flex justify-center border-r-2 border-[#191919] py-1 px-3 shrink-0" onclick={onClear}>Clear</button>
            <button class="flex justify-center border-r-2 border-[#191919] py-1 px-3 shrink-0" class:toggled={paused} onclick={togglePause}>Pause</button>
            <button class="flex justify-center border-r-2 border-[#191919] py-1 px-3 shrink-0 whitespace-nowrap" class:toggled={!showZeros} onclick={toggleHideZeros}>
                Show Zeros
            </button>

            <div class="grow"></div>

            <div class="flex py-1 px-3 gap-3 border-l-2 border-[#191919]">
                <input class="w-[200px]" type="range" min="10" max={maxTime} bind:value={timeRange}>
                <div>{timeRange} sec</div>
            </div>
        </div>

        <div class="flex px-3 font-mono py-1 bg-[#222] font-bold">
            <div class="overflow-ellipsis whitespace-nowrap basis-[400px] pl-7">Metric</div>
            <div class="basis-[140px]">Units</div>
            <div class="basis-[140px]">Value</div>
            <div class="basis-[140px]">Avg</div>
            <div class="basis-[140px]">Min</div>
            <div class="basis-[140px]">Max</div>
        </div>
        <div class="overflow-y-auto">
            {#each displayedMetrics as metric}
                {#if metric.data.length > 0 && (!showZeros || metric.max != 0)}
                    <ProfilerMetric {metric} {timeRange} />
                {/if}
            {/each}
        </div>
    {/if}
</div>

<style>
     .toggled {
        background-color: #444;
    }
</style>