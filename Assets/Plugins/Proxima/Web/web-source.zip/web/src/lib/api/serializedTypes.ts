export interface ConnectionInfo {
    DisplayName: string;
    InstanceId: string;
    ProductName: string;
    CompanyName: string;
    Platform: string;
    ProductVersion: string;
    ProximaVersion: string;
    ConnectionId: string;
}

export interface PropertyInfo {
    Name: string;
    Type: string;
    Value: any;
    Children: PropertyInfo[];
}

export interface ButtonInfo {
    Id: string;
    Text: string;
}

export interface ComponentInfo {
    Id: number;
    Order: number;
    Name: string;
    Properties: PropertyInfo[];
    Buttons: ButtonInfo[];
}

export interface ComponentList {
    Components: ComponentInfo[];
    Destroyed: number[];
}

export interface GameObjectInfo {
    Id: number;
    Name: string;
    ActiveSelf: boolean;
    Parent: number;
    Depth: number;
    SiblingIndex: number;
    ChildCount: number;
    Order: number;
    Tag: string;
    Layer: number;
    Scene: string;
}

export interface GameObjectList {
    GameObjects: GameObjectInfo[];
    Layers: string[];
}

export interface GameObjectChangeList extends GameObjectList {
    Destroyed: number[];
}

export interface LogInfo {
    LogTime: number;
    LogString: string;
    StackTrace: string;
    Type: number;
}

export interface ProfilerRecorderInfo {
    Name: string;
    Units: string;
}

export interface ProfilerDataInfo {
    TimeStamp: number;
    Data: number[];
}

export interface ProximaFileRequest {
    Id: string;
    Path: string;
    IfModifiedSince: string;
}

export interface ProximaFileResponse {
    Id: string;
    StatusCode: number;
    LastModifiedTime: string;
    ContentType: string;
    EncodedBytes: string;
}