<script lang="ts">
    import Chart from "./chart.svelte";
    import type { Metric } from "./metric";

    let {
        metric,
        timeRange
    }: {
        metric: Metric;
        timeRange: number;
    } = $props();

    let showChart = $state(false);

    function toggleChart() {
        showChart = !showChart;
    }

    let units = $derived(metric.units === "TimeNanoseconds" ? (metric.max > 10000 ? "ms" : "ns") :
        metric.units === "Bytes" ? "MB" : metric.units);

    let convert = $derived((metric.units === "TimeNanoseconds" && metric.max > 10000) || metric.units === "Bytes" ? 1e-6 : 1);

    let value = $derived((metric.data.getLast().value * convert).toFixed(1));
    let min = $derived((metric.min * convert).toFixed(1));
    let max = $derived((metric.max * convert).toFixed(1));
    let average = $derived((metric.average * convert).toFixed(1));
</script>

<div class="flex flex-col border-[#222] border-b-2 pl-3 pr-3 gap-2">
    <div class="flex py-1 font-mono">
        <div class="flex gap-3 basis-[400px]">
            <button onclick={() => toggleChart()} class="shrink-0">
                <img src="./icons/arrow.png" class="w-[15px]" class:rotate-90={showChart} alt="">
            </button>
            <div class="overflow-clip whitespace-nowrap text-ellipsis flex justify-between w-full pr-3">
                <div>
                    {metric.name}
                </div>
            </div>
        </div>
        <div class="basis-[140px]">({units}) </div>
        <div class="basis-[140px]">{value} </div>
        <div class="basis-[140px]">{average} </div>
        <div class="basis-[140px]">{min} </div>
        <div class="basis-[140px]">{max} </div>
    </div>
    {#if showChart}
        <Chart {metric} {timeRange} height={120} />
    {/if}
</div>
