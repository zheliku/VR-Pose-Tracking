import type { LogInfo } from './serializedTypes.js';

export function serializeLogs(logs: LogInfo[]) {
    var logStrings = logs.map(l => {
        const timestamp = new Date(l.LogTime);
        const day = (timestamp.getDate() < 10 ? "0" : "") + timestamp.getDate();
        const month = ((timestamp.getMonth() + 1) < 10 ? "0" : "") + (timestamp.getMonth() + 1);
        const year = timestamp.getFullYear();
        const hours = (timestamp.getHours() < 10 ? "0" : "") + timestamp.getHours();
        const minutes = (timestamp.getMinutes() < 10 ? "0" : "") + timestamp.getMinutes();
        const seconds = (timestamp.getSeconds() < 10 ? "0" : "") + timestamp.getSeconds();
        const timeStr = `[${month}-${day}-${year} ${hours}:${minutes}:${seconds}]`;
        const type = isMessage(l) ? 'Info' : isWarning(l) ? 'Warning' : 'Error';
        const logLines = l.LogString.trim().split("\n");
        if (l.StackTrace) {
            logLines.push(...l.StackTrace.trim().split("\n"));
        }
        return `${timeStr} ${type}: ${logLines.join("\n  ")}`;
    });

    return logStrings.join('\n');
}

export function isMessage(log: LogInfo) {
    return log.Type === 3;
}

export function isWarning(log: LogInfo) {
    return log.Type === 2;
}

export function isError(log: LogInfo) {
    return log.Type === 0 || log.Type === 1 || log.Type === 4;
}