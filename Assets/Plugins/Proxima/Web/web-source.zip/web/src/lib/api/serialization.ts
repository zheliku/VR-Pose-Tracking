const pi = (x: any) => {
    const n = Number.parseInt(x, 10);
    return isNaN(n) ? "0" : n.toString();
}

const pf = (x: any) => {
    const n = Number.parseFloat(x);
    return isNaN(n) ? "0" : n.toString();
}

export function serialize(type: string, data: any, quote = false): string {
    if (type === "Boolean") {
        return data ? "true" : "false";
    }

    if (type === "Single" || type === "Double") {
        return pf(data);
    }

    if (type === "Byte" || type === "SByte" ||
        type === "Int16" || type === "UInt16" ||
        type === "Int32" || type === "UInt32" ||
        type === "Int64" || type === "UInt64") {
        return pi(data);
    }

    if (type === 'Vector2Int') {
        return `[${pi(data[0])},${pi(data[1])}]`;
    }

    if (type === 'Vector2') {
        return `[${pf(data[0])},${pf(data[1])}]`;
    }

    if (type === 'Vector3Int') {
        return `[${pi(data[0])},${pi(data[1])},${pi(data[2])}]`;
    }

    if (type === 'Vector3' || type === 'Quaternion') {
        return `[${pf(data[0])},${pf(data[1])},${pf(data[2])}]`;
    }

    if (type === 'Vector4') {
        return `[${pf(data[0])},${pf(data[1])},${pf(data[2])},${pf(data[3])}]`;
    }

    if (type === 'Color') {
        return quote ? '"' + data + '"' : data;
    }

    if (type === 'Rect') {
        return `[${pf(data[0])},${pf(data[1])},${pf(data[2])},${pf(data[3])}]`;
    }

    if (type === 'Bounds') {
        return `[${pf(data[0])},${pf(data[1])},${pf(data[2])},${pf(data[3])},${pf(data[4])},${pf(data[5])}]`;
    }

    if (type === 'Boolean') {
        return data ? "true" : "false";
    }

    if (type === 'String') {
        return quote ? '"' + data + '"' : data;
    }

    if (type.startsWith('Array')) {
        const elementType = type.split(' ')[1];
        return `[${data.map((e: any) => serialize(elementType, e, true)).join(',')}]`;
    }

    if (type.startsWith('Enum') || type.startsWith('Flags') || type === 'LayerMask') {
        return data;
    }

    throw new Error("Cannot Serialize Unknown Type: " + type);
}

export function splitEnumType(type: string): [number, string][] {
    return type.split(' ')[1].split(',').map((e: string) => {
        let parts = e.split(':');
        return [+parts[1], parts[0]];
    });
}