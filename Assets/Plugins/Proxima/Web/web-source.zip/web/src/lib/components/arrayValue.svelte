<script lang="ts">
    import { onDestroy } from 'svelte';
    import type { PropertyInfo } from '$lib/api/serializedTypes';
    import PropertyItem from './propertyItem.svelte';
    import proxima from '$lib/api/proxima';
    import SerializedValue from './serializedValue.svelte';

    let {
        componentId,
        name,
        path,
        items = $bindable(),
        enabled,
        readonly
    }: {
        componentId: number;
        name: string;
        path: string;
        items: PropertyInfo[];
        enabled: boolean;
        readonly: boolean;
    } = $props();

    let expanded = $state(false);
    let dragFrom = $state(0)
    let dragTo = $state(0)
    let selected = $state(0)
    let itemPathPrefix = $derived(path + '.');

    function onPress(i: number) {
        if (enabled && !readonly) {
            dragFrom = i;
            dragTo = i;
            selected = i;
            window.addEventListener('mouseup', onRelease);
            window.addEventListener('touchend', onRelease);
        }
    }

    function onRelease() {
        if (dragFrom !== dragTo) {
            proxima.sendCommandNoResponse('MoveArrayElement', componentId, path, dragFrom, dragTo);
        }

        dragTo = -1;
        window.removeEventListener('mouseup', onRelease);
        window.removeEventListener('touchend', onRelease);
    }

    function onMove(i: number) {
        if (dragTo >= 0 && dragTo != i) {
            const v = items[dragTo];
            items.splice(dragTo, 1);
            items.splice(i, 0, v);
            items = items;
            dragTo = i;
            selected = i;
        }
    }

    function onTouchMove(e: TouchEvent) {
        const touch = e.touches[0];
        const target = document.elementFromPoint(touch.clientX, touch.clientY);
        if (target) {
            const index = target.getAttribute('data-index');
            if (index) {
                onMove(+index);
            }
        }
    }

    function toggleExpand() {
        expanded = !expanded;
    }

    function addItem() {
        setSize(items.length + 1);
    }

    function removeItem() {
        if (selected >= 0 && selected < items.length) {
            items.splice(selected, 1);
            items = items;
            proxima.sendCommandNoResponse('RemoveArrayElement', componentId, path, selected);
        } else if (items.length > 0) {
            items.pop();
            items = items;
            setSize(items.length);
        }
    }

    function onCountChange(e: Event) {
        const input = e.target as HTMLInputElement;
        const count = +input.value;
        setSize(count);
    }

    function setSize(count: number) {
        proxima.sendCommandNoResponse('SetArraySize', componentId, path, count);
    }

    onDestroy(() => {
        window.removeEventListener('mouseup', onRelease);
        window.removeEventListener('touchend', onRelease);
    });
</script>

<div class="flex w-full flex-col gap-2">
    <div class="flex grow justify-between">
        <button class="flex gap-1 items-center" onclick={toggleExpand}>
            <div class="w-[15px] text-center text-xs outline-none">
                <img src="./icons/arrow.png" class:rotate-90={expanded} alt="">
            </div>
            <div class="grow text-ellipsis overflow-clip whitespace-nowrap shrink-0 font-bold">{name}</div>
        </button>
        <input type="number" class="w-[60px]" value={items.length} disabled={!enabled} readOnly={readonly} onchange={onCountChange} />
    </div>
    {#if expanded}
        <div class="flex flex-col grow bg-[#343434] border-2 border-[#222]">
            {#each items as item, i}
                <div class="flex grow p-1" class:selected={selected === i} data-index={i}>
                    <div class="flex {!item.Children?.length ? 'w-1/3' : ''} select-none"
                        role="button"
                        tabindex={i}
                        onmousedown={() => onPress(i)}
                        ontouchstart={() => onPress(i)}
                        onmousemove={() => onMove(i)}
                        ontouchmove={e => { e.preventDefault(); onTouchMove(e); }}>
                        <div class="h-16px w-[24px] cursor-pointer select-none"><img draggable="false" src="./icons/element.png" alt=""/></div>
                        {#if !item.Children?.length}
                            <div class="text-ellipsis overflow-clip whitespace-nowrap shrink-0">Element {i}</div>
                        {/if}
                    </div>
                    {#if item.Children?.length > 0}
                        <SerializedValue {componentId} name={'Element ' + i} type={item.Type} value={item.Value} children={item.Children} childPathPrefix={itemPathPrefix + item.Name + '.'} {enabled} {readonly} />
                    {:else}
                        <PropertyItem {componentId} property={item} showName={false} pathPrefix={itemPathPrefix} {enabled} {readonly} />
                    {/if}
                </div>
            {:else}
                <div class="p-1 text-ellipsis overflow-clip whitespace-nowrap">List is Empty</div>
            {/each}
        </div>
        <div class="flex grow pr-2 justify-end mt-[-10px]">
            <div class="flex gap-2 bg-[#343434] border-2 border-[#222] p-1">
                <button class="select-none" onclick={addItem} class:darken={!enabled} disabled={!enabled || readonly}>
                    <img class="w-[18px]" src="./icons/plus.png" alt="">
                </button>
                <button class="select-none" onclick={removeItem} class:darken={!enabled} disabled={!enabled || readonly}>
                    <img class="w-[18px]" src="./icons/minus.png" alt="">
                </button>
            </div>
        </div>
    {/if}
</div>

<style>
    input {
        background-color: #222;
        border-radius: 5px;
        padding-left: 5px;
        min-width: 0;
    }

    input:disabled {
        background-color: #333;
        color: #888;
    }

    .selected {
        background-color: #444;
    }

    .darken {
        background-color: #333;
        color: #888;
    }
</style>