<script lang="ts">
    import proxima from "$lib/api/proxima";
    import { consoleHistory, consoleLines, consoleInput } from "$lib/util/store";
    import { onMount } from "svelte";

    let consoleWindow = $state<HTMLElement>();
    let entry = $state<HTMLInputElement>();
    let commands = $state<string[]>([]);
    let runQuery = $state('');

    let historySet = $derived($consoleHistory.filter((v, i, a) => a.lastIndexOf(v) === i));
    let historyIndex = $derived(historySet.length);

    const connected = proxima.connected;
    $effect(() => {
        if ($connected) {
            onConnected();
        }
    });

    function onConnected() {
        getCommands();

        if (runQuery) {
            $consoleLines.push('> Running Command: ' + runQuery);
            runCommand(runQuery, false);
            runQuery = '';
        }
    }

    async function getCommands() {
        commands = [];
        const commandsJson = await proxima.sendCommand('DumpCommands');
        commands = commandsJson.Commands.map((c: any) => c.Name);
        commands.push('Help');
        commands.push('History');
        commands.push('Clear');
        commands.sort((a, b) => a.localeCompare(b));
    }

    function parseCommand(input: string) {
        const cmd = input.split(' ')[0];
        const args: string[] = [];

        let q = false;
        let b = 0;
        let a = '';
        let bs = false;
        for (let i = cmd.length; i < input.length; i++) {
            const c = input[i];

            if (!q && b === 0 && c === ' ') {
                if (a) {
                    args.push(a);
                    a = '';
                }
                continue;
            }

            if (bs) {
                a += c;
                bs = false;
                continue;
            }

            if (!q && b === 0 && c === '"') {
                q = true;
                continue;
            }

            if (q && c === '"') {
                q = false;
                continue;
            }

            a += c;

            if (q && c === '\\') {
                bs = true;
                continue;
            }

            if (!q && c === '[') {
                b++;
                continue;
            }

            if (!q && c === ']') {
                b--;
                continue;
            }
        }

        if (a) {
            args.push(a);
        }

        return [cmd, ...args];
    }

    async function sendCommand(v: string) {
        const parts = parseCommand(v);
        let response = '';
        try {
            response = await proxima.sendCommand(parts[0], ...parts.slice(1));
        } catch (e: any) {
            var es = e.toString();
            response = es.startsWith('Error') ? es : 'Error: ' + es;
        }

        return response;
    }

    async function submit() {
        let v = $consoleInput.trim();
        $consoleInput = '';
        await runCommand(v, true);
    }

    async function runCommand(v: string, history: boolean) {
        if (v.length === 0) {
            return;
        }

        if (history) {
            $consoleLines = [...$consoleLines, '> ' + v];
            consoleWindow!.scrollTop = consoleWindow!.scrollHeight;
        }

        let response = '';
        const vl = v.toLowerCase();
        if (vl === 'h' || vl === 'history') {
            response = $consoleHistory.join('\n');
        } else if (vl === 'c' || vl === 'clear') {
            $consoleLines = [];
            return;
        } else {
            if (history) {
                $consoleHistory = [...$consoleHistory, v];
            }

            response = await sendCommand(v);
        }

        var responseLines = (response).toString().trimEnd().replaceAll('\r', '').replaceAll(' ', String.fromCharCode(160)).split('\n');
        $consoleLines = [...$consoleLines, ...responseLines];
        setTimeout(() => consoleWindow!.scrollTop = consoleWindow!.scrollHeight, 0);
    }

    let tabstr = '';
    let lastTyped = '';

    function onKeyDown(e: KeyboardEvent) {
        if (e.key === 'Enter') {
            e.preventDefault();
            submit();
        } else if (e.key === 'ArrowUp') {
            e.preventDefault();

            if (historyIndex === historySet.length) {
                lastTyped = $consoleInput;
            }

            historyIndex = Math.max(0, historyIndex - 1);
            $consoleInput = historySet[historyIndex];
        } else if (e.key === 'ArrowDown') {
            e.preventDefault();
            historyIndex = Math.min(historySet.length, historyIndex + 1)
            $consoleInput = historyIndex == historySet.length ? lastTyped : historySet[historyIndex];
        } else if (e.key === 'Tab') {
            e.preventDefault();
            const v = $consoleInput.trim();
            const split = v.toLowerCase().split(/\s+/);
            const help = split.length === 2 && (split[0] === 'help' || split[0] === '?');
            if (v.length === 0 || (!help && split.length > 1)) {
                return;
            }

            const cmd = help ? split[1] : split[0];
            if (!tabstr) {
                tabstr = cmd;
            }

            const prefix = help ? v.split(/\s+/)[0] + ' ' : '';
            const matches = commands.filter((command) => command.toLowerCase().startsWith(tabstr));
            if (matches.length > 0) {
                let idx = matches.findIndex(c => c.toLowerCase() === cmd);
                if (idx >= 0) {
                    if (e.shiftKey) {
                        idx = (idx - 1 + matches.length) % matches.length;

                    } else {
                        idx = (idx + 1) % matches.length;
                    }

                    $consoleInput = prefix + matches[idx];
                } else {
                    $consoleInput = prefix + matches[0];
                }
            }
        } else if (e.key === 'Escape') {
            e.preventDefault();
            $consoleInput = '';
        }

        if (e.key !== 'Tab' && e.key !== 'Shift') {
            tabstr = '';
        }
    }

    function runScript() {
        const input = document.createElement('input');
        input.style.display = 'hidden';
        input.type = 'file';
        input.onchange = async () => {
            if (input.files) {
                const file = input.files[0];
                if (file) {
                    const data = await file.text();
                    const lines = data.split(/\r?\n/);
                    $consoleLines.push('> Running Script: ' + file.name);
                    for (const line of lines) {
                        await runCommand(line, false);
                    }
                }
            }

            input.remove();
        };

        input.click();
    }

    onMount(() => {
        consoleWindow!.scrollTop = consoleWindow!.scrollHeight;
        entry!.focus();

        const urlSearchParams = new URLSearchParams(window.location.search);
        runQuery = urlSearchParams.get('run') || '';
    });
</script>

<div class="w-full h-full flex text-sm">
    <div class="w-full h-full flex flex-col">
        <div class="border-2 border-[#191919] h-[46px] flex items-center pl-5 gap-5 shrink-0">
            <button onclick={() => $consoleLines = []}>Clear</button>
            <button onclick={runScript}>Run Script</button>
        </div>
        <div bind:this={consoleWindow} class="border-2 border-t-0 border-[#191919] p-5 overflow-y-auto grow flex flex-col font-mono w-full break-all">
            {#each $consoleLines as line}
                {#if line.startsWith('> ')}
                    <div class="text-white w-full">{line}</div>
                {:else if line.startsWith('Error:')}
                    <div class="text-red-500 w-full">{line}</div>
                {:else if line}
                    <div>{line}</div>
                {:else}
                    &nbsp;
                {/if}
            {/each}
            <div class="flex">>&nbsp;<input spellcheck="false" bind:this={entry} bind:value={$consoleInput} class="bg-transparent outline-none grow" onkeydown={onKeyDown}></div>
            <!-- svelte-ignore a11y_click_events_have_key_events -->
            <div role="textbox" tabindex="0" class="grow cursor-text" onclick={() => entry!.select()}></div>
        </div>
    </div>
</div>