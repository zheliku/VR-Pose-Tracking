<script lang="ts">
    import { splitEnumType } from "$lib/api/serialization";
    import PrettyName from "$lib/util/prettyName";

    let {
        type,
        value,
        enabled,
        readonly,
        onChange
    }: {
        type: string;
        value: number;
        enabled: boolean;
        readonly: boolean;
        onChange?: (value: number) => void;
    } = $props();

    let select: HTMLSelectElement;

    let options = $derived(splitEnumType(type));

    function handleChange() {
        onChange?.(options[select.selectedIndex][0]);
    }
</script>

<div class="grow text-ellipsis overflow-clip whitespace-nowrap">
    <select bind:this={select} class="w-full" onchange={handleChange} class:darken={!enabled} disabled={!enabled || readonly}>
        {#each options as [index, name]}
            <option class="font-body" selected={value === index}>{PrettyName(name)}</option>
        {/each}
    </select>
</div>

<style>
    select {
        background-color: #222;
        border-radius: 5px;
        padding-left: 2px;
    }

    select:disabled {
        opacity: 1;
    }

    .darken {
        background-color: #333;
        color: #AAA;
    }
</style>