<script lang="ts">
    import proxima from "$lib/api/proxima";
    import type { ButtonInfo } from "$lib/api/serializedTypes";

    let {
        componentId,
        button,
        enabled,
        readonly
    }: {
        componentId: number;
        button: ButtonInfo;
        enabled: boolean;
        readonly: boolean;
    } = $props();
</script>

<div class="flex grow">
    <div class="w-1/3"></div>
    <button disabled={!enabled || readonly} class="py-1 px-2 text-center bg-[#444] rounded-sm disabled:bg-[#333] disabled:text-[#888] grow"
        onclick={() => proxima.sendCommandNoResponse('InvokeButton', componentId, button.Id)}>
        {button.Text}
    </button>
</div>