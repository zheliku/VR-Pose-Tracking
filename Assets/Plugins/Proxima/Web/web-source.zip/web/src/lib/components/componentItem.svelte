<script lang="ts">
	import type { ComponentInfo } from "$lib/api/serializedTypes";
	import PropertyItem from "./propertyItem.svelte";
    import PrettyName from "$lib/util/prettyName";
    import proxima from "$lib/api/proxima";
    import { serialize } from "$lib/api/serialization";
    import ButtonItem from "./buttonItem.svelte";

    let {
        component,
        enabled,
        readonly
    }: {
        component: ComponentInfo;
        enabled: boolean;
        readonly: boolean;
    } = $props();

    let expanded = $state(component.Properties.length > 0);
    $effect(() => { component; expanded = true });
    let enabledProp = $derived(component.Properties.find(p => p.Name === 'enabled'));
    let icon = $derived((component.Name === "Transform" ? './icons/d_Transform_Icon.png' : './icons/script.png'));
    let properties = $derived(component.Properties.filter(p => p.Name !== "enabled"));

    function setEnabled(e: Event) {
        if (enabledProp) {
            const input = e.target as HTMLInputElement;
            enabledProp.Value = input.checked
            const serializedValue = serialize(enabledProp.Type, enabledProp.Value);
            proxima.sendCommandNoResponse('SetProperty', component.Id, enabledProp.Name, serializedValue);
        }
    }

    function destroyComponent() {
        proxima.sendCommand('DestroyComponent', component.Id);
    }
</script>

<hr class="w-full border-[#111]">

<!-- svelte-ignore a11y_click_events_have_key_events -->
<!-- svelte-ignore a11y_no_static_element_interactions -->
<div class="flex items-center bg-[#404040] cursor-pointer" class:mb-2={expanded} onclick={() => expanded = !expanded}>
    <div class="w-[20px] text-center">
        {#if properties.length > 0}
            <img class="ml-[2px]" src="./icons/arrow.png" class:rotate-90={expanded} alt="">
        {/if}
    </div>
    <div class="w-[15px] mr-1 text-center">
        {#if enabledProp}
            <input type="checkbox" class="translate-y-[1px]" disabled={!enabled || readonly} checked={enabledProp.Value} onchange={setEnabled} onclick={e => e.stopPropagation()} />
        {/if}
    </div>
    <img src={icon} class="w-[15px] mr-1" alt="">
    {PrettyName(component.Name)}
    <div class="flex-grow"></div>
    {#if component.Name !== "Transform"}
        <button class="pr-2 font-mono" onclick={destroyComponent}>Destroy</button>
    {/if}
</div>

{#if expanded}
    <div class="flex flex-col gap-1 pl-3 pr-3">
        {#if properties.length > 0 || component.Buttons.length > 0}
            <div class="h-2"></div>
        {/if}
        {#each component.Buttons as button}
            <ButtonItem componentId={component.Id} {button} {enabled} {readonly} />
        {/each}
        {#each properties as property}
            <PropertyItem componentId={component.Id} {property} {enabled} {readonly} />
        {/each}
        {#if properties.length > 0}
            <div class="h-4"></div>
        {/if}
    </div>
{/if}