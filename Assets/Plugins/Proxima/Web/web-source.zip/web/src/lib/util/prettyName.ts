const expecptions = ['iPhone', 'iPad', 'x86', 'x64'];

export default function PrettyName(name: string) {
    if (expecptions.includes(name)) {
        return name;
    }

    return name
        .replace(/^m_/g, '')
        .replace(/^_/g, '')
        .replace(/([A-Z]+)([A-Z][a-z])/g, '$1 $2')
        .replace(/([a-z])([A-Z]+)/g, '$1 $2')
        .replace(/([a-z])(\d+)/g, '$1 $2')
        .replace(/^\w/, m => m[0].toUpperCase());
}