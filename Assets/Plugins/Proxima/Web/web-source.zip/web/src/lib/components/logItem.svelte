<script lang="ts">
	import type { LogInfo } from "$lib/api/serializedTypes";
    import LogText from "./logText.svelte";
    import { onMount, onDestroy } from "svelte";

    let {
        log,
        collapse,
        searchString,
        bg,
        onSelect
    } : {
        log: LogInfo;
        collapse: number;
        searchString: string;
        bg: string;
        onSelect: () => void;
    } = $props();

    let timestamp = $derived(new Date(log.LogTime));
    let day = $derived((timestamp.getDate() < 10 ? "0" : "") + timestamp.getDate());
    let month = $derived((timestamp.getMonth() < 9 ? "0" : "") + (timestamp.getMonth() + 1));
    let year = $derived(timestamp.getFullYear());
    let hours = $derived((timestamp.getHours() < 10 ? "0" : "") + timestamp.getHours());
    let minutes = $derived((timestamp.getMinutes() < 10 ? "0" : "") + timestamp.getMinutes());
    let seconds = $derived((timestamp.getSeconds() < 10 ? "0" : "") + timestamp.getSeconds());
    let stackTop = $derived(log.StackTrace.split('\n')[0]);

    let observer: IntersectionObserver;
    let visible = $state(false);
    let root: HTMLElement;

    onMount(() =>{
        observer = new IntersectionObserver((entries, observer) => {
            if (entries[0].isIntersecting) {
                visible = true;
                observer.disconnect();
            }
        }, {
            root: root.parentElement,
            rootMargin: (window.innerHeight * 10) + "px"
        });

        observer.observe(root);
    });

    onDestroy(() => {
        observer.disconnect();
    });
</script>


<div bind:this={root} class="w-full p-1" style="background-color: {bg};">
    {#if visible}
        <button class="flex w-full justify-between" onclick={() => onSelect?.()}>
            <div class="flex w-full text-left items-center gap-2 pl-2 relative">
                {#if log.Type === 0 || log.Type === 1 || log.Type === 4}
                    <img src="./icons/d_console.erroricon.png" class="w-[25px] h-[25px]" alt="">
                {:else if log.Type === 2}
                    <img src="./icons/d_console.warnicon.png" class="w-[25px] h-[25px]" alt="">
                {:else}
                    <img src="./icons/d_console.infoicon.png" class="w-[25px] h-[25px]" alt="">
                {/if}
                <div class="w-full">
                    <p class="whitespace-nowrap overflow-clip text-ellipsis w-full">{#if log.LogTime > 0}[{month}-{day}-{year} {hours}:{minutes}:{seconds}] {/if}<LogText text={log.LogString.split('\n')[0]} {searchString} /></p>
                    <p class="whitespace-nowrap overflow-clip text-ellipsis w-full"><LogText text={stackTop} {searchString} /></p>
                    {#if collapse}
                        <p class="absolute bottom-[5px] right-[5px] text-xs bg-gray-400 text-white rounded-xl p-2">{collapse}</p>
                    {/if}
                </div>
            </div>
        </button>
    {:else}
        <div style="height: 46px"></div>
    {/if}
</div>