<script lang="ts">
    import type { ComponentList } from "$lib/api/serializedTypes";
    import ComponentItem from "./componentItem.svelte";
    import type { GameObjectInfo } from "$lib/api/serializedTypes";
    import proxima from '$lib/api/proxima';
    import { onDestroy } from "svelte";
    import { layers } from "$lib/util/store";

    let { selected = $bindable() } : { selected: GameObjectInfo | undefined } = $props();

    const connected = proxima.connected;
    const proLink = "https://www.unityproxima.com";
    const features = proxima.features;

    let components = $state<ComponentList>();
    let streamId = $state('');
    let streaming = $state<GameObjectInfo>();
    let componentToAdd = $state('');

    let enabled = $derived(!!$connected);
    let inspectorEditFeature = $derived($features.includes('inspectorEdit'));
    let readonly = $derived(!inspectorEditFeature);
    let selectableLayers = $derived($layers?.filter(l => l));
    let selectedLayer = $derived(selected ? selectableLayers.findIndex(l => l === $layers[selected!.Layer]) : 0);

    function stopStream() {
        if ($connected && streamId) {
            proxima.stopStream('Components', streamId);
        }

        components = undefined;
        streamId = '';
        streaming = undefined;
    }

    onDestroy(stopStream);

    async function getComponents(gameObject: GameObjectInfo) {
        if (streaming?.Id === gameObject.Id) {
            return;
        }

        stopStream();
        streaming = gameObject;
        streamId = proxima.startStream('Components', [gameObject.Id.toString()], (data, error) => {
            if (error) {
                console.error(error);
            } else {
                if (!components) {
                    components = data as ComponentList;
                    return;
                }

                const changeList = data as ComponentList;
                components.Components = components.Components.filter(ci => !changeList.Destroyed.includes(ci.Id));
                for (const newCi of changeList.Components) {
                    const ci = components.Components.find(ci => ci.Id === newCi.Id);
                    if (ci) {
                        ci.Name = newCi.Name;
                        newCi.Properties.forEach(p => {
                            const prop = ci.Properties.find(p2 => p2.Name === p.Name);
                            if (prop) {
                                prop.Value = p.Value;
                                prop.Children = p.Children;
                            }
                        });
                    } else {
                        components.Components.push(newCi);
                    }
                }

                components.Components.sort((a, b) => a.Order - b.Order);
            }
        });
    }

    $effect(() => {
        if (selected) {
            getComponents(selected);
        } else {
            stopStream();
        }
    });

    function setActive(e: Event) {
        if (selected) {
            var input = e.target as HTMLInputElement;
            proxima.sendCommand('SetActive', selected.Id, input.checked);
            selected.ActiveSelf = input.checked;
        }
    }

    function setName(e: Event) {
        if (selected) {
            var input = e.target as HTMLInputElement;
            proxima.sendCommand('SetName', selected.Id, input.value);
            selected.Name = input.value;
        }
    }

    function setTag(e: Event) {
        if (selected) {
            var input = e.target as HTMLInputElement;
            proxima.sendCommand('SetTag', selected.Id, input.value);
            selected.Tag = input.value;
        }
    }

    function setLayer(e: Event) {
        if (selected) {
            var select = e.target as HTMLSelectElement;
            var layer = $layers.findIndex(l => l === selectableLayers[select.selectedIndex]);
            proxima.sendCommand('SetLayer', selected.Id, layer);
            selected.Layer = layer;
        }
    }

    function addComponent(e: Event) {
        e.preventDefault();
        if (selected && componentToAdd) {
            proxima.sendCommand('AddGameObjectComponent', selected.Id, componentToAdd);
            componentToAdd = '';
        }
    }
</script>

<div class="grow p-3 pl-0 pr-0 flex flex-col h-full overflow-y-auto text-sm">
    <div class="flex items-center pr-3">
        <p class="grow text-xl m-5">Inspector</p>
        {#if !inspectorEditFeature}
            <a class="text-orange-300 bg-[#191919] px-2 py-1 text-sm rounded text-sm font-bold font-logo" referrerpolicy="origin" target='_blank' rel='external' href={proLink}>Upgrade to Pro to Edit</a>
        {/if}
    </div>
    {#if selected}
        <div class="pr-3 pb-4">
            <div class="flex ml-5 gap-3">
                <input type="checkbox" checked={selected.ActiveSelf} disabled={!$connected || readonly} onchange={setActive}>
                <input value="{selected.Name}" disabled={!$connected} readOnly={readonly} class="w-full" onchange={setName}>
            </div>
            <div class="mt-2 w-full gap-5 flex justify-between">
                <div class="flex grow gap-3 ml-3">
                    Tag <input class="grow" value={selected.Tag} onchange={setTag} disabled={!$connected} readOnly={readonly} />
                </div>
                <div class="flex grow gap-3">
                    Layer
                    <select class="grow" onchange={setLayer} class:darken={!enabled} disabled={!enabled || readonly}>
                        {#each selectableLayers as layer, i}
                            <option class="font-body" selected={selectedLayer === i}>{layer}</option>
                        {/each}
                    </select>
                </div>
            </div>
        </div>

        {#each components?.Components as component (component.Id)}
            <ComponentItem {component} {enabled} {readonly} />
        {/each}

        <form class="flex gap-2 m-2 items-center" onsubmit={addComponent}>
            <input type="text" bind:value={componentToAdd} class="font-mono py-1 px-2 flex-grow" placeholder="e.g. BoxCollider">
            <button class="pt-1 border-2 py-1 px-2 rounded border-[#444] bg-[#222] hover:bg-[#333] font-mono">Add</button>
        </form>
    {/if}
</div>

<style>
    input {
        background-color: #222;
        border-radius: 5px;
        padding-left: 5px;
    }

    input:disabled {
        background-color: #333;
        color: #888;
    }

    .darken {
        background-color: #333;
        color: #888;
    }

    select {
        background-color: #222;
        border-radius: 5px;
        padding-left: 5px;
    }

    select:disabled {
        opacity: 1;
    }
</style>