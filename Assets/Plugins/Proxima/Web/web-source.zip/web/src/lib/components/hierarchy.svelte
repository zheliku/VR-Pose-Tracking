<script lang="ts">
    import proxima from "$lib/api/proxima";
    import type { GameObjectChangeList, GameObjectInfo, GameObjectList } from "$lib/api/serializedTypes";
    import { expandedGameObjects, expandedScenes, layers, selectedGameObjectId } from "$lib/util/store";
    import { onDestroy, onMount } from "svelte";
    import GameObjectItem from "./gameObjectItem.svelte";

    let { selected = $bindable() } : { selected: GameObjectInfo | undefined } = $props();

    const connected = proxima.connected;
    let gameObjectList = $state<GameObjectList | undefined>();
    let dragging = $state<HTMLElement | null>(null);
    let searchFilter = $state<((goi: GameObjectInfo) => boolean) | null>(null);
    let streamId = $state('');
    let searchQuery = $state('');
    let showHidden = $state(false);
    let gameObjectQuery = '';

    $effect(() => { searchQuery; onSearch(); });
    let gois = $derived(gameObjectList?.GameObjects ?? []);
    let filteredGois = $derived(searchFilter ? gois.filter(searchFilter).sort((a, b) => a.Name.localeCompare(b.Name)) : null);
    let firstGois = $derived(gois.filter(goi => goi.Scene).filter((item, index, self) => self.findIndex(g => g.Scene === item.Scene) === index));
    let scenes = $derived(firstGois.map(goi => goi.Scene));
    $effect(() => { $layers = gameObjectList?.Layers ?? []; });

    $effect(() => {
        if (selected) {
            $selectedGameObjectId = selected.Id;
        }
    });

    $effect(() => {
        if ($connected) {
            onConnected();
        }
    });

    onMount(() => {
        const urlSearchParams = new URLSearchParams(window.location.search);
        gameObjectQuery = urlSearchParams.get('go') ?? '';
        searchQuery = urlSearchParams.get('s') ?? '';
    });

    function onConnected() {
        selected = undefined;
        gameObjectList = undefined;
        streamId = proxima.startStream('GameObjects', [], (data, error) => {
            if (error) {
                console.error(error);
            } else {
                if (!gameObjectList) {
                    const goiList = data as GameObjectList;
                    goiList.GameObjects.sort((a, b) => a.Order - b.Order);
                    gameObjectList = goiList;
                    selected = goiList.GameObjects.find(goi => goi.Id === $selectedGameObjectId);
                } else {
                    const changeList = data as GameObjectChangeList;
                    gameObjectList.GameObjects = gameObjectList.GameObjects.filter(goi => !changeList.Destroyed.includes(goi.Id));
                    for (const newGoi of changeList.GameObjects) {
                        const goi = gameObjectList.GameObjects.find(goi => goi.Id === newGoi.Id);
                        if (goi) {
                            Object.assign(goi, newGoi);
                            if (goi.Id === selected?.Id) {
                                selected = goi;
                            }
                        } else {
                            gameObjectList.GameObjects.push(newGoi);
                        }
                    }

                    if (selected && changeList.Destroyed.includes(selected.Id)) {
                        selected = undefined;
                    }

                    gameObjectList.GameObjects.sort((a, b) => a.Order - b.Order);
                    gameObjectList = gameObjectList;
                }

                if (gameObjectQuery) {
                    const goi = gameObjectList.GameObjects.find(goi => goi.Name.toLowerCase() === gameObjectQuery.toLowerCase());
                    if (goi) {
                        selected = goi;
                        gameObjectQuery = '';
                        ensureVisible(selected);
                    }
                }
            }
        });
    }

    $effect(() => {
        if ($connected) {
            proxima.sendCommand('SetShowHidden', showHidden);
        }
    });

    onDestroy(() => {
        if ($connected && streamId) {
            proxima.stopStream('GameObjects', streamId);
        }

        streamId = '';
    })

    function onSearch() {
        const searchTerm = searchQuery.trim().toLowerCase()
        if (searchTerm) {
            searchFilter = (goi: GameObjectInfo) => goi.Name.toLowerCase().includes(searchTerm);
        } else {
            searchFilter = null;
        }
    }

    function clearHover(element: HTMLElement | null) {
        if (element) {
            element.style.borderTop = "3px solid transparent";
            element.style.borderBottom = "3px solid transparent";
            element.style.backgroundColor = "transparent";
        }
    }

    function getGameObjectElement(e: Event) {
        let element: HTMLElement | null = (e.target as HTMLElement);
        while (element && !element.id.startsWith('go-item')) {
            element = element.parentElement;
        }

        return element;
    }

    function onMouseDown(e: MouseEvent) {
        if ($connected) {
            dragging = getGameObjectElement(e);
        }
    }

    function getInsertType(e: MouseEvent, element: HTMLElement) {
        const rect = element.getBoundingClientRect();
        const aboveY = rect.top + rect.height / 3;
        const belowY = rect.top + rect.height * 2 / 3;
        if (e.clientY < aboveY) {
            return 'above';
        } else if (e.clientY > belowY) {
            return 'below';
        } else {
            return 'child';
        }
    }

    function elementToGameObjectInfo(e: HTMLElement) {
        let id = +e!.id.split('go-item-')[1];
        return gois.find(goi => goi.Id === id);
    }

    function setParent(goi: GameObjectInfo, parentId: number, index: number) {
        proxima.sendCommand('SetParent', goi.Id, parentId, index);
    }

    function setScene(goi: GameObjectInfo, sceneIndex: number, index: number) {
        proxima.sendCommand('SetScene', goi.Id, sceneIndex, index);
    }

    function getVisibleGameObjects() {
        let depth = 0;
        let result: GameObjectInfo[] = [];
        for (const goi of gois) {
            if (goi.Depth < depth) {
                depth = goi.Depth;
            }

            if (goi.Depth === depth) {
                result.push(goi);
            }

            if ($expandedGameObjects.has(goi.Id)) {
                depth++;
            }
        }

        return result;
    }

    function insertAbove(goi: GameObjectInfo, target: GameObjectInfo) {
        const visible = getVisibleGameObjects();
        const idx = visible.indexOf(target);
        if (idx > 0) {
            if (target.Depth === 0) {
                setScene(goi, scenes.indexOf(target.Scene), target.SiblingIndex);
            } else {
                insertBelow(goi, visible[idx - 1]);
            }
        } else {
            setScene(goi, 0, 0);
        }
    }

    function insertBelow(goi: GameObjectInfo, target: GameObjectInfo) {
        if ($expandedGameObjects.has(target.Id) && target.ChildCount > 0) {
            setParent(goi, target.Id, 0);
        } else if (target.Depth === 0 && target.Scene !== goi.Scene) {
            setScene(goi, scenes.indexOf(target.Scene), target.SiblingIndex + 1);
        } else if (goi.Parent === target.Parent && goi.SiblingIndex < target.SiblingIndex) {
            setParent(goi, target.Parent, target.SiblingIndex);
        } else {
            setParent(goi, target.Parent, target.SiblingIndex + 1);
        }
    }

    function insertChild(goi: GameObjectInfo, target: GameObjectInfo) {
        setParent(goi, target.Id, target.ChildCount);
    }

    function onMouseUp(e: MouseEvent) {
        e.stopPropagation();
        const element = getGameObjectElement(e);
        if (element) {
            clearHover(element);
            if (dragging && element !== dragging) {
                const draggingGoi = elementToGameObjectInfo(dragging);
                const targetGoi = elementToGameObjectInfo(element);
                if (draggingGoi && targetGoi) {
                    switch (getInsertType(e, element)) {
                        case "above": insertAbove(draggingGoi, targetGoi); break;
                        case "below": insertBelow(draggingGoi, targetGoi); break;
                        case "child": insertChild(draggingGoi, targetGoi); break;
                    }
                }
            }
        }

        if (!element && !dragging) {
            selected = undefined;
        }

        dragging = null;
    }

    function onMouseMove(e: MouseEvent) {
        if (dragging) {
            const element = getGameObjectElement(e);
            if (element) {
                clearHover(element);
                switch (getInsertType(e, element)) {
                    case "above": element.style.borderTop = "3px solid #234A6C"; break;
                    case "below": element.style.borderBottom = "3px solid #234A6C"; break;
                    case "child": element.style.backgroundColor = "#234A6C"; break;
                }
            }
        }
    }

    function onMouseOut(e: MouseEvent) {
        clearHover(getGameObjectElement(e));
    }

    function onBlur(e: Event) {
        clearHover(getGameObjectElement(e));
    }

    function onKeyDown(e: KeyboardEvent) {
        if (selected) {
            if (e.key === 'ArrowUp') {
                const visible = getVisibleGameObjects();
                const idx = visible.indexOf(selected);
                if (idx > 0) {
                    selected = visible[idx - 1];
                }
            } else if (e.key === 'ArrowDown') {
                const visible = getVisibleGameObjects();
                const idx = visible.indexOf(selected);
                if (idx < visible.length - 1) {
                    selected = visible[idx + 1];
                }
            } else if (e.key === 'ArrowRight') {
                if (selected.ChildCount > 0 && !$expandedGameObjects.has(selected.Id)) {
                    $expandedGameObjects.add(selected.Id)
                    $expandedGameObjects = $expandedGameObjects;
                    gois = gois;
                    return;
                }

                const visible = getVisibleGameObjects();
                let idx = visible.indexOf(selected);
                while (idx++ < visible.length) {
                    const next = visible[idx];
                    if (next.ChildCount > 0) {
                        selected = next;
                        break;
                    }
                }
            } else if (e.key === 'ArrowLeft') {
                if ($expandedGameObjects.has(selected.Id)) {
                    $expandedGameObjects.delete(selected.Id);
                    $expandedGameObjects = $expandedGameObjects;
                    gois = gois;
                    return;
                }

                const visible = getVisibleGameObjects();
                let idx = visible.indexOf(selected);
                while (idx-- >= 0) {
                    const prev = visible[idx];
                    if (prev.ChildCount > 0) {
                        selected = prev;
                        break;
                    }
                }
            } else if (e.key === 'Delete') {
                destroySelected();
                return;
            } else if (e.key === 'Escape') {
                selected = undefined;
                return;
            } else if (e.key === 'd' && e.ctrlKey) {
                duplicateSelected();
                return;
            }
        }
    }

    function toggleExpand(scene: string) {
        if ($expandedScenes.has(scene)) {
            $expandedScenes.delete(scene);
        } else {
            $expandedScenes.add(scene);
        }

        $expandedScenes = $expandedScenes;
    }

    function getParent(goi: GameObjectInfo) {
        if (goi.Parent) {
            return gois.find(g => g.Id === goi.Parent);
        }

        return null;
    }

    function ensureVisible(goi: GameObjectInfo) {
        let parent = getParent(goi);
        while (parent) {
            $expandedGameObjects.add(parent.Id);
            goi = parent;
            parent = getParent(goi);
        }

        $expandedScenes.add(goi.Scene);
        $expandedScenes = $expandedScenes;
        $expandedGameObjects = $expandedGameObjects;
    }

    function newGameObject() {
        proxima.sendCommand('CreateGameObject', selected?.Id ?? 0);
    }

    function duplicateSelected() {
        if (selected) {
            proxima.sendCommand('DuplicateGameObject', selected.Id);
        }
    }

    function destroySelected() {
        if (selected) {
            proxima.sendCommand('DestroyGameObject', selected.Id);
            selected = undefined;
        }
    }
</script>

<div class="flex flex-col h-full overflow-y-auto p-8 text-sm">
    <div class="flex justify-between items-center">
        <p class="text-xl mb-5">GameObjects</p>
        <div class="flex gap-2"><input type="checkbox" bind:checked={showHidden}><p>Show Hidden</p></div>
    </div>
    <input class="w-full placeholder-[#555]" placeholder="Search..." bind:value={searchQuery}>
    <div class="flex my-2 gap-2">
        <button onclick={newGameObject} class="bg-[#222] hover:bg-[#333] text-white py-0.5 w-1/3 text-center rounded border-2 border-[#444]">New</button>
        <button onclick={duplicateSelected} class="bg-[#222] hover:bg-[#333] text-white py-0.5 w-1/3 text-center rounded border-2 border-[#444]">Duplicate</button>
        <button onclick={destroySelected} class="bg-[#422] hover:bg-[#522] text-white py-0.5 w-1/3 text-center rounded border-2 border-[#444]">Destroy</button>
    </div>
    <div class="flex-grow"
        role="tree"
        tabindex="0"
        onmousedown={onMouseDown}
        onmouseup={onMouseUp}
        onmousemove={onMouseMove}
        onblur={onBlur}
        onmouseout={onMouseOut}>

        {#if searchFilter !== null}
            {#each filteredGois || [] as goi}
                <GameObjectItem bind:selected {gois} gameObject={goi} tree={false} onkeydown={onKeyDown} />
            {/each}
        {:else}
            {#each gois as goi}
                {#if goi.Depth === 0}
                    {#if firstGois.includes(goi)}
                        <div class="mt-4 font-bold flex items-center">
                            <button class="shrink-0" onclick={() => toggleExpand(goi.Scene)}>
                                <img src="./icons/arrow.png" class="w-[15px]" class:rotate-90={$expandedScenes.has(goi.Scene)} alt="">
                            </button>
                            <img src="./icons/scene.png" class="w-[20px]" alt="">
                            {goi.Scene.split("#")[0]}
                        </div>
                    {/if}

                    {#if $expandedScenes.has(goi.Scene)}
                        <GameObjectItem bind:selected {gois} gameObject={goi} tree={true} onkeydown={onKeyDown} />
                    {/if}
                {/if}
            {/each}
        {/if}
    </div>
</div>

<style>
    input {
        background-color: #222;
        border-radius: 5px;
        padding-left: 5px;
    }

    input:disabled {
        background-color: #333;
        color: #888;
    }
</style>