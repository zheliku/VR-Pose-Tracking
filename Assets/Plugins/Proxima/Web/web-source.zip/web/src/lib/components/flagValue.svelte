<script lang="ts">
    import PrettyName from '$lib/util/prettyName';
    import { onMount, onDestroy } from 'svelte';

    let {
        options,
        value = $bindable(),
        enabled,
        readonly,
        onChange
    }: {
        options: [number, string][];
        value: number;
        enabled: boolean;
        readonly: boolean;
        onChange?: (value: number) => void;
    } = $props();

    let validOptions = $derived(options.filter(e => e[0] > 0));
    let mask = $derived(validOptions.reduce((a, e) => a | e[0], 0));
    let selected = $derived(validOptions.filter(e => (value & e[0]) == e[0]).map(e => PrettyName(e[1])).join(', '));
    let everything = $derived((mask & value) === mask);

    let open = $state(false);
    let button: HTMLButtonElement;
    let dropdown = $state<HTMLDivElement>();

    function onMouseUp(e: MouseEvent) {
        if (e.target !== button &&
            !button.contains(e.target as Node) &&
            (!dropdown?.contains(e.target as Node) || e.target instanceof HTMLButtonElement)) {

            setTimeout(() => open = false, 0);
        }
    };

    function onNothing() {
        onChange?.(0);
    }

    function onEverything() {
        onChange?.(mask);
    }

    function onToggle(mask: number) {
        let newValue = value;
        if ((value & mask) === mask) {
            newValue = value & ~mask;
        } else {
            newValue = value | mask;
        }

        onChange?.(newValue);
    }

    onMount(() => {
        window.addEventListener('mouseup', onMouseUp);
    });

    onDestroy(() => {
        window.removeEventListener('mouseup', onMouseUp);
    });
</script>

<div class="relative w-full">
    <button class="flex justify-between w-full bg-[#222] pl-[5px] pr-[2px] items-center text-ellipsis overflow-clip whitespace-nowrap"
        bind:this={button}
        onclick={() => open = !open}
        class:darken={!enabled}
        disabled={!enabled || readonly}>

        {everything ? "Everything" : selected || 'Nothing'}
        <img src="./icons/arrow.png" class="rotate-90" alt="">
    </button>

    {#if open}
        <div class="flex flex-col absolute top-full z-50 overflow-y-auto max-h-[400px] bg-[#222] w-full" bind:this={dropdown}>
            <button class="hover:bg-[#234A6C] pl-[15px] text-left" onclick={() => onNothing()}>Nothing</button>
            <button class="hover:bg-[#234A6C] pl-[15px] text-left" onclick={() => onEverything()}>Everything</button>
            {#each validOptions as [mask, name]}
                <button class="flex hover:bg-[#234A6C] items-center" onclick={() => onToggle(mask)}>
                    <div class="w-[15px]">
                        {#if (value & mask) === mask}
                            <img class="W-full" src="./icons/check.png" alt="">
                        {/if}
                    </div>
                    {PrettyName(name)}
                </button>
            {/each}
        </div>
    {/if}
</div>

<style>
    .darken {
        background-color: #333;
        color: #888;
    }
</style>