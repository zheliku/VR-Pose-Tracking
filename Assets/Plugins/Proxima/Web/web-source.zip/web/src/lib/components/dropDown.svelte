<script lang="ts">
    import { onMount } from 'svelte';

    let {
        cls = "",
        disabled = false,
        button: buttonSnippet,
        options: optionsSnippet
    }: {
        cls?: string;
        disabled?: boolean;
        button: import('svelte').Snippet;
        options: import('svelte').Snippet;
    } = $props();

    let open = $state(false);
    let button: HTMLButtonElement;

    function onMouseUp(e: MouseEvent) {
        if (e.target !== button && !button.contains(e.target as Node)) {
            setTimeout(() => open = false, 0);
        }
    };

    onMount(() => {
        window.addEventListener('mouseup', onMouseUp);

        return () => {
            window.removeEventListener('mouseup', onMouseUp);
        };
    });
</script>

<div class="relative {cls}">
    <button bind:this={button} class="flex" {disabled} onclick={() => open = !open}>
        {@render buttonSnippet()}
    </button>

    {#if open}
        <div class="flex flex-col absolute top-full z-50 overflow-y-auto">
            {@render optionsSnippet()}
        </div>
    {/if}
</div>