<script lang="ts">
    import proxima from "$lib/api/proxima";

    let {
        collapsed
    }: {
        collapsed: boolean;
    } = $props();

    const connected = proxima.connected;
    const error = proxima.error;
    const selected = proxima.selected;
</script>

{#if !collapsed}
    {#if $error}
        <div class="p-3 w-full text-center bg-red-900">{$error}</div>
    {:else if $connected}
        <div class="p-3 w-full text-center bg-green-900">Connected</div>
    {:else if $selected}
        <div class="p-3 w-full text-center bg-yellow-900">Connecting...</div>
    {:else}
        <div class="p-3 w-full text-center bg-[#191919]">Disconnected</div>
    {/if}

    {#if $connected}
        <div class="p-3 w-full bg-slate-800 text-xs text-center overflow-clip whitespace-nowrap text-ellipsis">
            {$connected?.DisplayName} {$connected?.ProductVersion} ({$connected?.ProductName})
        </div>
    {/if}
{:else}
    {#if $error}
        <div class="h-[36px] bg-red-900"></div>
    {:else if $connected}
        <div class="h-[36px] bg-green-900"></div>
    {:else if $selected}
        <div class="h-[36px] bg-yellow-900"></div>
    {:else}
        <div class="h-[36px] bg-[#191919]"></div>
    {/if}
{/if}