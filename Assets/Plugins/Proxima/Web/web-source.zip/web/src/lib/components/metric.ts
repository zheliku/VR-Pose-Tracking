import type CircularBuffer from '../util/circularBuffer';

export type DataPoint = {
    time: number;
    value: number;
}

export type Metric = {
    name: string;
    units: string;
    max : number;
    min : number;
    average : number;
    data : CircularBuffer<DataPoint>;
}