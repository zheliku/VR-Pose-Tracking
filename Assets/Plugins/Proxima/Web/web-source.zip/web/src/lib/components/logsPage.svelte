<script lang="ts">
	import LogItem from "$lib/components/logItem.svelte";
    import { onDestroy } from "svelte";
    import type { LogInfo } from "$lib/api/serializedTypes";
	import proxima from "$lib/api/proxima";
	import fileSaver from 'file-saver';
    const { saveAs } = fileSaver;
	import LogText from "$lib/components/logText.svelte";
    import DropDown from "$lib/components/dropDown.svelte";
    import { serializeLogs, isMessage, isWarning, isError } from "$lib/api/logs.js";

    let selected = $state<LogInfo>();
    let logs = $state<LogInfo[]>([]);
    let logWindow = $state<HTMLElement>();
    let paused = $state(false);
    let streamId = $state('');
    let collapse = $state(false);
    let search = $state('');
    let logFilesAvailable = $state(false);

    let stack = $derived(selected?.StackTrace.split('\n') ?? []);

    const connected = proxima.connected;

    $effect(() => {
        if ($connected) {
            onConnected();
        } else {
            onDisconnected();
        }
    });

    onDestroy(() => {
        onPause();
    });

    async function onConnected() {
        if (!paused) {
            onResume();
        }

        logFilesAvailable = await proxima.sendCommand('GetLogFilesAvailable');
    }

    function onDisconnected() {
        streamId = '';
        logFilesAvailable = false;
    }

    function onPause() {
        if ($connected && streamId) {
            proxima.stopStream('LogStream', streamId);
            streamId = '';
            paused = true;
        }
    }

    function onResume() {
        paused = false;
        logs = [];

        if (!streamId && $connected) {
            streamId = proxima.startStream('LogStream', [], (data: any, error: string) => {
                if (error) {
                    console.error(error);
                    return;
                } else {
                    const scrollDown = logWindow!.scrollHeight - logWindow!.scrollTop === logWindow!.clientHeight;
                    logs = [...logs, ...(data as LogInfo[])];
                    if (scrollDown) {
                        setTimeout(() => logWindow!.scrollTop = logWindow!.scrollHeight, 0);
                    }
                }
            });
        }
    }

    function onClear() {
        logs = [];
    }

    function onCollapse() {
        collapse = !collapse;
    }

    function createFileTimestamp(date: Date) {
        const day = (date.getDate() < 10 ? "0" : "") + date.getDate();
        const m = date.getMonth() + 1;
        const month = (m < 10 ? "0" : "") + m;
        const year = date.getFullYear();
        const hours = (date.getHours() < 10 ? "0" : "") + date.getHours();
        const minutes = (date.getMinutes() < 10 ? "0" : "") + date.getMinutes();
        const seconds = (date.getSeconds() < 10 ? "0" : "") + date.getSeconds();
        return `${year}-${month}-${day}_${hours}-${minutes}-${seconds}`;
    }

    async function onSave() {
        try {
            const logString = serializeLogs(logs);
            saveAs(new Blob([logString]), `ProximaLog_${createFileTimestamp(new Date(Date.now()))}.log`);
        } catch (e) {
            console.error(e);
        }
    }

    async function onDownload() {
        try {
            const data = await proxima.sendCommand('GetLogFile');
            saveAs(new Blob([data]), `Player_${createFileTimestamp(new Date(Date.now()))}.log`);
        } catch (e) {
            console.error(e);
        }
    }

    async function onDownloadPrevious() {
        try {
            const data = await proxima.sendCommand('GetPreviousLogFile');
            saveAs(new Blob([data]), `Player-prev_${createFileTimestamp(new Date(Date.now()))}.log`);
        } catch (e) {
            console.error(e);
        }
    }

    function getLogTypeFromStack(stack: string) {
        if (stack.includes('LogWarning')) {
            return 2;
        } else if (stack.includes('LogError') || stack.includes('LogException')) {
            return 0;
        } else {
            return 3;
        }
    }

    function parseLogFile(data: string, lastModified: number) {
        const newLogs: LogInfo[] = [];
        data = data.replace(/\r\n/g, '\n');

        const unityLogRegex = /(.+)(\n((([\w<>]+[\.:])+\S+ ?\(.*\)\n)+( ?\n\(Filename: .+)?))?/g;
        const proximaRegex = /\[(\S+ ?\S+)\]\ (\w+): (.*)((\n  .*)*)/g
        const isProximaLog = data.match(proximaRegex);

        while (true) {
            if (isProximaLog) {
                const proximaLog = proximaRegex.exec(data);
                if (!proximaLog) {
                    break;
                }

                let timestamp = new Date(proximaLog[1]);
                if (!timestamp.getTime()) {
                    const parseTime = proximaLog[1].split(':');
                    timestamp = new Date(lastModified);
                    timestamp.setHours(parseInt(parseTime[0]), parseInt(parseTime[1]), parseInt(parseTime[2]));
                }

                newLogs.push({
                    Type: proximaLog[2] === 'Warning' ? 2 : proximaLog[4] === 'Error' ? 0 : 3,
                    LogString: proximaLog[3],
                    StackTrace: proximaLog[4],
                    LogTime: timestamp.getTime()
                });
            } else {
                const result = unityLogRegex.exec(data)
                if (!result) {
                    break;
                }

                const stack = result[3] || '';
                const message = result[1];

                // We generally can't tell if a message has multiple lines, especially if there's no stack.
                // This is special cast for exceptions which print the stack and start with ' at ' on the stack lines.
                // In this case, append to the previous message.
                if (message.startsWith("  at ") && newLogs[newLogs.length - 1]?.StackTrace.length === 0) {
                    newLogs[newLogs.length - 1].Type = getLogTypeFromStack(stack);
                    newLogs[newLogs.length - 1].LogString += '\n' + message;
                    newLogs[newLogs.length - 1].StackTrace = stack;
                    continue;
                }

                newLogs.push({
                    Type: getLogTypeFromStack(stack),
                    LogString: message,
                    StackTrace: stack,
                    LogTime: 0
                });
            }
        }

        logs = newLogs;
    }

    function onLoad() {
        onPause();
        const input = document.createElement('input');
        input.style.display = 'hidden';
        input.type = 'file';
        input.accept = '.log';
        input.onchange = async () => {
            if (input.files) {
                const file = input.files[0];
                if (file) {
                    logs = [{ Type: 3, LogString: 'Loading log file...', StackTrace: '', LogTime: 0}]
                    const data = await file.text();
                    parseLogFile(data, file.lastModified);
                }
            }

            input.remove();
        };
        input.click();
    }

    function count(arr: any[], predicate: (item: any) => boolean) {
        let count = 0;
        for (const item of arr) {
            if (predicate(item)) {
                count++;
            }
        }

        return count;
    }

    let messages = $derived(count(logs, isMessage));
    let warnings = $derived(count(logs, isWarning))
    let errors = $derived(count(logs, isError));

    let showMessages = $state(true);
    let showWarnings = $state(true);
    let showErrors = $state(true);

    function shouldDisplay(log: LogInfo, search: string, showMessages: boolean, showWarnings: boolean, showErrors: boolean) {
        if (search) {
            if (!log.LogString.toLowerCase().includes(search) &&
                !log.StackTrace.toLowerCase().includes(search)) {
                return false;
            }
        }

        if (isMessage(log) && showMessages) {
            return true;
        } else if (isWarning(log) && showWarnings) {
            return true;
        } else if (isError(log) && showErrors) {
            return  true;
        }

        return false;
    }

    function cyrb53(str: string, seed = 0) {
        let h1 = 0xdeadbeef ^ seed;
        let h2 = 0x41c6ce57 ^ seed;

        for (let i = 0, ch; i < str.length; i++) {
            ch = str.charCodeAt(i);
            h1 = Math.imul(h1 ^ ch, 2654435761);
            h2 = Math.imul(h2 ^ ch, 1597334677);
        }

        h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
        h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
        return 4294967296 * (2097151 & h2) + (h1 >>> 0);
    }

    function getCollapseLogs(logs: LogInfo[]) {
        let firstLogs = new Map<number, LogInfo>();
        for (const log of logs) {
            const key = cyrb53(`${log.LogString}\n${log.StackTrace}\n${log.Type}`);
            if (firstLogs.has(key)) {
            } else {
                firstLogs.set(key, log);
            }
        }

        return [...firstLogs.values()];
    }

    function getCollapseCount(logs: LogInfo[]) {
        let firstLogs = new Map<number, LogInfo>();
        let count: number[] = [];
        for (const log of logs) {
            const key = cyrb53(`${log.LogString}\n${log.StackTrace}\n${log.Type}`);
            if (firstLogs.has(key)) {
                count[count.length - 1]++;
            } else {
                firstLogs.set(key, log);
                count.push(0);
            }
        }

        return count;
    }

    function onSearch(e: Event) {
        search = (e.target as HTMLInputElement).value;
    }

    let searchString = $derived(search.toLowerCase());
    let filtered = $derived(logs.filter(log => shouldDisplay(log, searchString, showMessages, showWarnings, showErrors)));
    let finalLogs = $derived(collapse ? getCollapseLogs(filtered) : filtered);
    let collapseCount = $derived(collapse ? getCollapseCount(filtered) : []);
</script>

<div class="flex flex-col w-full text-sm">
    <div class="flex flex-col border-[#191919] h-1/2 w-full">
        <div class="flex w-full border-b-2 border-[#191919]">
            <div class="flex shrink-0">
                <button class="border-r-2 border-[#191919] p-1 pr-3 pl-3 shrink-0" onclick={onClear}>Clear</button>
                <button class="border-r-2 border-[#191919] p-1 pl-3 pr-3 shrink-0" class:toggled={collapse} onclick={onCollapse}>Collapse</button>
                {#if paused}
                    <button class="border-r-2 border-[#191919] p-1 pl-3 pr-3 shrink-0" onclick={onResume}>Resume</button>
                {:else}
                    <button class="border-r-2 border-[#191919] p-1 pl-3 pr-3 shrink-0" onclick={onPause}>Pause</button>
                {/if}

                <DropDown cls="w-full">
                    {#snippet button()}
                        <div class="border-r-2 border-[#191919] p-1 pl-3 pr-3 flex gap-3 items-center shrink-0">
                            Save
                            <img class="rotate-90" src="./icons/arrow.png" alt="" />
                        </div>
                    {/snippet}

                    {#snippet options()}
                        <div class="flex flex-col bg-[#2D2D2D]">
                            <button class="hover:bg-[#444] w-full p-2 text-left border-[#191919] border-2 border-b-0 whitespace-nowrap" disabled={logs.length === 0} onclick={onSave}>Save Proxima Log</button>
                            <button class="hover:bg-[#444] w-full p-2 text-left border-[#191919] border-2 border-b-0 whitespace-nowrap" disabled={!logFilesAvailable} onclick={onDownload}>Download Unity Log</button>
                            <button class="hover:bg-[#444] w-full p-2 text-left border-[#191919] border-2 whitespace-nowrap" disabled={!logFilesAvailable} onclick={onDownloadPrevious}>Download Previous Unity Log</button>
                        </div>
                    {/snippet}
                </DropDown>

                <button class="border-r-2 border-[#191919] p-1 pl-3 pr-3 shrink-0" onclick={onLoad}>Load</button>
            </div>
            <div class="grow shrink flex justify-end pl-1 pr-1">
                <input class="placeholder-[#555] text-left grow shrink max-w-[300px] min-w-[20px] mt-1 mb-1" placeholder="Search..." onchange={onSearch}>
            </div>
            <div class="flex shrink-0">
                <button class="border-r-2 border-[#191919] pr-1 flex gap-2 w-[70px] justify-center items-center border-l-2 whitespace-nowrap shrink-0" class:toggled={showMessages} onclick={() => showMessages = !showMessages} >
                    <img src="./icons/d_console.infoicon.png" class="w-[15px]" alt="">{messages}
                </button>
                <button class="border-r-2 border-[#191919] pl-1 pr-1 flex gap-2 w-[70px] justify-center items-center whitespace-nowrap shrink-0" class:toggled={showWarnings} onclick={() => showWarnings = !showWarnings} >
                    <img src="./icons/d_console.warnicon.png" class="w-[15px]" alt="">{warnings}
                </button>
                <button class="pl-1 pr-1 flex gap-2 w-[70px] items-center justify-center whitespace-nowrap shrink-0" class:toggled={showErrors} onclick={() => showErrors = !showErrors} >
                    <img src="./icons/d_console.erroricon.png" class="w-[15px]" alt="">{errors}
                </button>
            </div>
        </div>
        <div bind:this={logWindow} class="overflow-y-auto flex flex-col overflow-x-clip w-full h-full">
            {#each finalLogs as log, i}
                <LogItem {log} collapse={collapseCount[i]} {searchString} bg={selected === log ? "#234A6C" : (i % 2 === 0) ? "#323232": "#383838"} onSelect={() => selected = log} />
            {/each}
        </div>
    </div>

    <div class="flex flex-col border-t-2 border-[#191919] p-2 overflow-y-auto h-1/2 w-full">
        {#if selected}
            {#each selected.LogString.split("\n") as line}
                <LogText text={line} {searchString} />
            {/each}
            {#each stack as line}
                <LogText text={line} {searchString} />
            {/each}
        {/if}
    </div>
</div>

<style>
    input {
        background-color: #222;
        border-radius: 5px;
        padding-left: 5px;
    }

    button:disabled {
        color: #666666;
    }

    .toggled {
        background-color: #444;
    }
</style>