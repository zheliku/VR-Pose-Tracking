<script lang="ts">
    import proxima from "$lib/api/proxima";
    import ConnectCard from '$lib/components/connectCard.svelte';
    import { onDestroy } from "svelte";

    const connected = proxima.connected;
    const error = proxima.error;
    const instances = proxima.instances;

    $effect(() => { proxima.pollList = !$connected });

    onDestroy(() => {
        proxima.pollList = false;
    });
</script>


<div class="flex w-full">
    <div class="flex flex-col gap-5 p-8 overflow-y-auto w-[464px]">
        <h1 class="text-xl">Welcome to Proxima Inspector!</h1>

        {#if $connected}
            <p>You're connected! Select a page on the left to view information about your game.</p>
            <ConnectCard connectionInfo={$connected} />
        {:else}
            <p>To get started, click below to connect to your device.</p>

            {#if $error}
                <p class="text-red-500">{$error}</p>
            {/if}

            {#each $instances as instance}
                <ConnectCard connectionInfo={instance} />
            {/each}
        {/if}
    </div>
    <div class="grow border-l-2 border-[#222] bg-[#2d2d2d]"></div>
</div>