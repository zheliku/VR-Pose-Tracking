import { browser } from '$app/environment';
import { writable } from 'svelte/store';

export const hierarchyWidth = writable(0);
export const selectedGameObjectId = writable(0);
export const expandedGameObjects = writable<Set<number>>(new Set());
export const expandedScenes = writable<Set<string>>(new Set());
export const consoleHistory = writable<string[]>([]);
export const consoleInput = writable('');
export const consoleLines = writable<string[]>(['Welcome to the console. For a list of commands type "?"']);
export const layers = writable<string[]>([]);
export const scaleLinked = writable(true);

function init() {
    const hierarchyWidthValue = localStorage.getItem('hierarchyWidth');
    if (hierarchyWidthValue !== null) {
        hierarchyWidth.set(+hierarchyWidthValue);
    }

    const consoleHistoryValue = localStorage.getItem('consoleHistory');
    if (consoleHistoryValue !== null) {
        consoleHistory.set(JSON.parse(consoleHistoryValue));
    }

    hierarchyWidth.subscribe((value) => {
        localStorage.setItem('hierarchyWidth', value.toString());
    });

    consoleHistory.subscribe((value) => {
        localStorage.setItem('consoleHistory', JSON.stringify(value));
    });
}

if (browser) {
    init();
}