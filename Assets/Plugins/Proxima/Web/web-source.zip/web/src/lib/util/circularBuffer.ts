export default class CirclularBuffer<T> {
    private buffer: T[];
    private last = -1;
    private _length = 0;
    public get length() { return this._length; }

    public constructor(private capacity: number) {
        this.buffer = new Array<T>(capacity);
    }

    public push(value: T) {
        this.last = (this.last + 1) % this.capacity;
        this.buffer[this.last] = value;

        if (this._length < this.capacity) {
            this._length++;
        }
    }

    public get(index: number) {
        if (index >= this._length) {
            throw new Error("Index out of range");
        }

        if (this._length < this.capacity) {
            return this.buffer[index];
        }

        return this.buffer[(this.last + 1 + index) % this.capacity];
    }

    public getLast() {
        return this.get(this._length - 1);
    }

    public clear() {
        this.last = -1;
        this._length = 0;
    }
}