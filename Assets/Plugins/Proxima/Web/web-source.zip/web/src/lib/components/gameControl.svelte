<script lang="ts">
    import proxima from "$lib/api/proxima";

    let {
        collapsed
    }: {
        collapsed: boolean;
    } = $props();

    const connected = proxima.connected;

    let paused = $state(false);

    $effect(() => {
        if ($connected) {
            onConnected();
        }
    });

    async function onConnected() {
        paused = await proxima.sendCommand('IsPaused');
    }

    async function togglePause() {
        paused = !paused;
        if (paused) {
            proxima.sendCommandNoResponse('Pause');
        } else {
            proxima.sendCommandNoResponse('Resume');
        }
    }
</script>

{#if $connected}
    <div class="flex justify-center">
        <button class="bg-[#191919] rounded-lg border-[#444] border-2" class:p-3={!collapsed} class:p-2={collapsed} onclick={togglePause}>
            <img class="h-[20px]" src="{paused ? "./icons/play.png" : "./icons/pause.png"}" alt="" />
        </button>
    </div>
{/if}