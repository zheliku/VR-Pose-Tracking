<script lang="ts">
    import { layers } from '$lib/util/store';
    import FlagValue from './flagValue.svelte';

    let {
        value = $bindable(),
        enabled,
        readonly,
        onChange
    }: {
        value: number;
        enabled: boolean;
        readonly: boolean;
        onChange?: (value: number) => void;
    } = $props();

    let options = $derived($layers.map<[number, string]>((l, i) => [1 << i, l]).filter(x => x[1]));
</script>

<FlagValue {options} bind:value {enabled} {readonly} {onChange} />