<script lang="ts">
    import PrettyName from "$lib/util/prettyName";

    let {
        type,
        value,
        enabled
    }: {
        type: string;
        value: any;
        enabled: boolean;
    } = $props();
</script>

<div class="grow text-ellipsis overflow-clip whitespace-nowrap bg-[#222] pl-[5px] rounded-[5px] text-left" class:disabled={!enabled}>{(value || 'None') + ` (${PrettyName(type.split(' ')[1])})`}</div>

<style>
    .disabled {
        background-color: #333;
        color: #888;
    }
</style>