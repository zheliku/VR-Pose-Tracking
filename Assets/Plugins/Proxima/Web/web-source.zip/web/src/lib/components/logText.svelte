<script lang="ts">
    let {
        text,
        searchString
    }: {
        text: string;
        searchString: string;
    } = $props();

    let richText = $derived(text
        .replace(/<color="?(\w+|#\w{6})"?>/g, '<span style="color: $1">')
        .replace(/<\/color>/g, '</span>')
        .replace(/<size=(\d+)>/g, '<span style="font-size: $1px">')
        .replace(/<\/size>/g, '</span>'));

    function getParts(text: string, searchString: string) {
        let result = [];
        const lower = text.toLowerCase();
        for (let i = 0; i < text.length;) {
            const index = lower.indexOf(searchString, i);
            if (index >= 0) {
                if (index - i > 0) {
                    result.push(text.substring(i, index));
                }

                result.push(text.substring(index, index + searchString.length));
                i = index + searchString.length;
            } else {
                result.push(text.substring(i));
                break;
            }
        }

        return result;
    }

    let parts = $derived(searchString ? getParts(richText, searchString) : [richText]);
</script>

<span class="break-words">
    {#each parts as part}
        {#if searchString && part.toLowerCase() === searchString}
            <span class="bg-[#30638f]">{part}</span>
        {:else}
            {@html part}
        {/if}
    {/each}
</span>
