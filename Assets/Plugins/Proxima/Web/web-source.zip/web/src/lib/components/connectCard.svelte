<script lang="ts">
    import proxima from "$lib/api/proxima";
    import type { ConnectionInfo } from "$lib/api/serializedTypes";

    let {
        connectionInfo
    }: {
        connectionInfo: ConnectionInfo;
    } = $props();

    const connected = proxima.connected;

    function onSelect() {
        const password = prompt("Enter password");
        if (password) {
            proxima.select(connectionInfo, password);
        }
    }

    function onDisconnect() {
        proxima.disconnect();
    }
</script>

<div class="border-2 border-[#222] bg-[#222] flex flex-col w-[400px]" class:border-green-900={$connected}>
    <div class="flex pl-4 pr-4 text-orange-300" class:bg-green-900={$connected}>
        <div class="w-[100px]">Name</div>
        {connectionInfo.DisplayName}
    </div>
    <div class="flex pl-4 pr-4 bg-[#333]">
        <div class="w-[100px]">Product</div>
        <div>{connectionInfo.ProductName}</div>
    </div>
    <div class="flex pl-4 pr-4">
        <div class="w-[100px]">Company</div>
        <div>{connectionInfo.CompanyName}</div>
    </div>

    <div class="flex pl-4 pr-4 bg-[#333]">
        <div class="w-[100px]">Platform</div>
        <div>{connectionInfo.Platform}</div>
    </div>

    <div class="flex pl-4 pr-4 pb-1">
        <div class="w-[100px]">Version</div>
        <div>{connectionInfo.ProductVersion}</div>
    </div>

    {#if $connected}
        <button class="p-2 bg-slate-800 blue" onclick={onDisconnect}>Disconnect</button>
    {:else}
        <button class="p-2 bg-slate-800 blue" onclick={onSelect}>Connect</button>
    {/if}
</div>

<style>
    .blue:hover {
        background-color: #1e40af;
    }
</style>