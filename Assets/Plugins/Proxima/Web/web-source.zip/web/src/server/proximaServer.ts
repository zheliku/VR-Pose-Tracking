import type { Server } from 'http';
import { WebSocket, WebSocketServer } from 'ws';
import type { RawData } from 'ws';
import { v4 as uuidv4, v5 as uuidv5 } from 'uuid';

enum ProximaRequestType {
    Command = 0,
    StreamStart = 1,
    StreamStop = 2,
    List = 3,
    Select = 4
}

interface ProximaRequest {
    Id: string;
    Type: ProximaRequestType;
    Cmd: string;
    Args: string[];
}

interface ProximaResponse {
    Id: string;
    Data?: any;
    Error?: string;
}

interface ProximaInstanceHello {
    DisplayName: string;
    InstanceId: string;
    ProductName: string;
    CompanyName: string;
    Platform: string;
    ProductVersion: string;
    ProximaVersion: string;
    ConnectionId: string;
    Password: string;
}

interface Instance {
    hello: ProximaInstanceHello;
    password: string;
    instanceId: string;
    ws: WebSocket;
}

enum LogLevel {
    Debug = 0,
    Info = 1,
    Warn = 2,
    Error = 3,
}

class Logger {
    public static logLevel = LogLevel.Info;

    public static log(level: LogLevel, msg: string) {
        if (level >= Logger.logLevel) {
            console.log(msg);
        }
    }
}

export default class ProximaServer {
    private instances = new Map<string, Instance>();
    private clientToInstance = new Map<WebSocket, WebSocket>();
    private instanceToClient = new Map<WebSocket, WebSocket>();

    public wss: WebSocketServer;

    constructor(server: Server, path: string = '') {
        this.wss = new WebSocketServer({ server, path });
        this.wss.on('connection', ws => this.onConnection(ws));
    }

    private sendToClient(ws: WebSocket, resp: ProximaResponse) {
        ws.send(JSON.stringify(resp), { binary: false });
    }

    private sendToInstance(ws: WebSocket, req: ProximaRequest) {
        ws.send(JSON.stringify(req), { binary: false });
    }

    private onConnection(ws: WebSocket) {
        (ws as any).id = uuidv4();
        Logger.log(LogLevel.Info, "New Connection: " + (ws as any).id);
        ws.on('message', (message, isBinary) => this.onMessage(ws, message, isBinary));
        ws.on('close', () => this.onClose(ws));
    }

    private getLength(msg: RawData) {
        if (msg instanceof Buffer) {
            return msg.length;
        } else if (msg instanceof ArrayBuffer) {
            return msg.byteLength;
        } else {
            throw new Error("Unsupported message type");
        }
    }

    private onMessage(ws: WebSocket, msg: RawData, isBinary: boolean) {
        if (Logger.logLevel <= LogLevel.Debug) {
            var log = this.getLength(msg) > 1000 ? msg.slice(0, 1000).toString() + '...' : msg.toString();
            Logger.log(LogLevel.Debug, 'Received from ' + (ws as any).id + ': ' + log);
        }

        if (this.tryForwardToClient(ws, msg, isBinary) || this.tryForwardToInstance(ws, msg, isBinary)) {
            return;
        }

        let msgObj: any;
        try {
            msgObj = JSON.parse(msg.toString());
        } catch (e) {
            Logger.log(LogLevel.Error, 'Invalid JSON. Closing connection.');
            ws.close();
            return;
        }

        if (msgObj.DisplayName) {
            this.onInstanceHello(ws, msgObj as ProximaInstanceHello);

        } else if (msgObj.Type !== undefined) {
            const req = msgObj as ProximaRequest;
            if (req.Type === ProximaRequestType.List) {
                this.onList(ws, req);
            } else if (req.Type === ProximaRequestType.Select) {
                this.onSelect(ws, req);
            } else {
                Logger.log(LogLevel.Error, 'Unknown request type. Closing connection.');
                ws.close();
            }

        } else {
            Logger.log(LogLevel.Error, 'Unknown message. Closing connection.');
            ws.close();
        }
    }
    private onInstanceHello(ws: WebSocket, hello: ProximaInstanceHello) {
        const id = hello.InstanceId;
        const newId = uuidv5(hello.InstanceId + (ws as any)._socket.remoteAddress, uuidv5.URL);
        const password = hello.Password;
        hello.Password = '';
        hello.InstanceId = newId;
        this.instances.set(newId, { hello, ws, instanceId: id, password });
        Logger.log(LogLevel.Info, "New Proxima Instance: " + newId);
    }

    private onList(ws: WebSocket, req: ProximaRequest) {
        if ((ws as any).listRequestTime && Date.now()- (ws as any).listRequestTime < 1000) {
            this.sendToClient(ws, {
                Id: req.Id,
                Error: 'Too many requests.',
            });

            return;
        }

        (ws as any).listRequestTime = Date.now();

        this.sendToClient(ws, {
            Id: req.Id,
            Data: [...this.instances.values()].map(i => i.hello),
            Error: '',
        });
    }

    private onSelect(ws: WebSocket, req: ProximaRequest) {
        if ((ws as any).selectRequestTime && Date.now() - (ws as any).selectRequestTime < 1000) {
            this.sendToClient(ws, {
                Id: req.Id,
                Error: 'Too many requests.',
            });

            return;
        }

        (ws as any).selectRequestTime = Date.now();

        const instance = this.instances.get(req.Cmd);
        if (!instance) {
            this.sendToClient(ws, {
                Id: req.Id,
                Error: 'Not found',
            });

            return;
        }

        if (instance.password !== req.Args[0]) {
            this.sendToClient(ws, {
                Id: req.Id,
                Error: 'Invalid password',
            });

            return;
        }

        this.clientToInstance.set(ws, instance.ws);
        this.instanceToClient.set(instance.ws, ws);
        this.instances.delete(req.Cmd);
        this.sendToClient(ws, {
            Id: req.Id,
            Data: 'OK'
        });

        this.sendToInstance(instance.ws, {
            Id: uuidv4(),
            Type: ProximaRequestType.Select,
            Cmd: instance.instanceId,
            Args: [instance.password],
        });

        Logger.log(LogLevel.Info, "Client " + (ws as any).id + " selected instance " + req.Cmd);
    }

    private tryForwardToInstance(ws: WebSocket, msg: RawData, binary: boolean) {
        const instance = this.clientToInstance.get(ws);
        if (instance) {
            Logger.log(LogLevel.Debug, "Forward to instance: " + (instance as any).id);
            instance.send(msg, { binary });
            return true;
        }

        return false;
    }

    private tryForwardToClient(ws: WebSocket, msg: RawData, binary: boolean) {
        const client = this.instanceToClient.get(ws);
        if (client) {
            Logger.log(LogLevel.Debug, "Forward to client: " + (client as any).id);
            client.send(msg, { binary });
            return true;
        }

        return false;
    }

    private onClose(ws: WebSocket) {
        Logger.log(LogLevel.Info, 'Connection closed: ' + (ws as any).id);
        const instance = this.clientToInstance.get(ws);
        if (instance) {
            instance.close();
        }

        const client = this.instanceToClient.get(ws);
        if (client) {
            client.close();
        }

        this.clientToInstance.delete(ws);
        this.instanceToClient.delete(ws);
        const available = [...this.instances.entries()].find(([_, v]) => v.ws === ws);
        if (available) {
            this.instances.delete(available[0]);
        }
    }
}