import * as http from "http";
import express from 'express';
import ProximaServer from "./proximaServer.js";

const app = express();
app.use(express.static('build'));
const httpServer = http.createServer(app);
const proximaServer = new ProximaServer(httpServer);

const port = process.env.PORT || 5173;

app.use('/api', (req, res) => {
    proximaServer.wss.handleUpgrade(req, req.socket, Buffer.alloc(0), (ws, req) => {
        proximaServer.wss.emit('connection', ws, req);
    });
});

app.listen(port, () => {
    console.log(`Proxima server listening on port ${port}`)
});