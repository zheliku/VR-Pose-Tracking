import { WebSocketServer } from 'ws';
import { v4 as uuidv4 } from 'uuid';
var ProximaRequestType;
(function (ProximaRequestType) {
    ProximaRequestType[ProximaRequestType["Command"] = 0] = "Command";
    ProximaRequestType[ProximaRequestType["StreamStart"] = 1] = "StreamStart";
    ProximaRequestType[ProximaRequestType["StreamStop"] = 2] = "StreamStop";
    ProximaRequestType[ProximaRequestType["List"] = 3] = "List";
    ProximaRequestType[ProximaRequestType["Select"] = 4] = "Select";
})(ProximaRequestType || (ProximaRequestType = {}));
export default class ProximaServer {
    constructor(server) {
        this.availableHosts = new Map();
        this.clientToHost = new Map();
        this.hostToClient = new Map();
        this.wss = new WebSocketServer({ server, path: '/api' });
        this.wss.on('connection', ws => this.onConnection(ws));
    }
    send(ws, resp) {
        ws.send(JSON.stringify(resp), { binary: false });
    }
    onConnection(ws) {
        console.log("New Websocket Connection");
        ws.on('message', (message) => this.onMessage(ws, message));
        ws.on('close', () => this.onClose(ws));
    }
    onMessage(ws, msg) {
        console.log('Received: ' + msg);
        const msgObj = JSON.parse(msg); // TODO: This is over-parsing, we just care about a few fields.
        // If this is a new host, add it to the list of available hosts.
        if (msgObj.AppName) {
            this.onGameHello(ws, msgObj);
            // If this is a client request.
        }
        else if (msgObj.Type !== undefined) {
            this.onRequest(ws, msg, msgObj);
            // This is a response, forward it to the client.
        }
        else {
            this.onResponse(ws, msg, msgObj);
        }
    }
    onGameHello(ws, hello) {
        const id = hello.AppName + " " + uuidv4();
        this.availableHosts.set(id, ws);
    }
    onRequest(ws, msg, req) {
        // If this is a list request, send the list of available hosts.
        if (req.Type === ProximaRequestType.List) {
            console.log("Hosts: " + Array.from(this.availableHosts.keys()).join('\n'));
            this.send(ws, {
                Id: req.Id,
                Data: Array.from(this.availableHosts.keys()).join('\n'),
                Error: '',
            });
            // If this is a select request, map the client to the host.
        }
        else if (req.Type === ProximaRequestType.Select) {
            const host = this.availableHosts.get(req.Cmd);
            if (host) {
                this.clientToHost.set(ws, host);
                this.hostToClient.set(host, ws);
                this.availableHosts.delete(req.Cmd);
                this.send(ws, {
                    Id: req.Id,
                    Data: 'OK',
                    Error: '',
                });
            }
            else {
                this.send(ws, {
                    Id: req.Id,
                    Data: '',
                    Error: 'Not found',
                });
            }
            // Otherwise, forward the request to the host.
        }
        else {
            const host = this.clientToHost.get(ws);
            if (host) {
                console.log("Forward to host");
                host.send(msg, { binary: false });
            }
        }
    }
    onResponse(ws, msg, resp) {
        const client = this.hostToClient.get(ws);
        if (client) {
            console.log("Forward to client");
            client.send(msg, { binary: false });
        }
    }
    onClose(ws) {
        console.log('Connection closed');
        const host = this.clientToHost.get(ws);
        if (host) {
            host.close();
        }
        const client = this.hostToClient.get(ws);
        if (client) {
            client.close();
        }
        this.clientToHost.delete(ws);
        this.hostToClient.delete(ws);
        const available = [...this.availableHosts.entries()].find(([_, v]) => v === ws);
        if (available) {
            this.availableHosts.delete(available[0]);
        }
    }
}
