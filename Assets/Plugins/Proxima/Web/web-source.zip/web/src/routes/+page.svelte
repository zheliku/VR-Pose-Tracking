<script lang="ts">
	import proxima from "$lib/api/proxima";
    import "../app.css";
	import { onMount } from "svelte";
    import { browser } from '$app/environment';
    import ConnectionStatus from "$lib/components/connectionStatus.svelte";
    import GameControl from "$lib/components/gameControl.svelte";
    import ConnectPage from "$lib/components/connectPage.svelte";
    import InspectorPage from "$lib/components/inspectorPage.svelte";
    import LogsPage from "$lib/components/logsPage.svelte";
    import ConsolePage from "$lib/components/consolePage.svelte";
    import ProfilerPage from "$lib/components/profilerPage.svelte";

    const selected = proxima.selected;
    const features = proxima.features;
    let consoleFeature = $derived($features.includes('console'));
    let collapsed = $state(false);
    let page = $state('connection');
    const proLink = 'https://www.unityproxima.com';

    onMount(() => {
        if (browser) {
            const urlSearchParams = new URLSearchParams(window.location.search);
            if (urlSearchParams.has('collapsed')) {
                collapsed = !!urlSearchParams.get('collapsed');
            } else {
                collapsed = window.localStorage.getItem("collapsed") === "true";
            }

            if (urlSearchParams.has('pass')) {
                const pass = urlSearchParams.get('pass')!;
                proxima.autoConnect(pass);
            }

            if (urlSearchParams.has('page')) {
                page = urlSearchParams.get('page')!;
            }

            proxima.start();
        }
    });

    function toggle() {
        collapsed = !collapsed;
        window.localStorage.setItem("collapsed", collapsed.toString());
    }

    function goto(dest: string) {
        if (dest === 'console' && !consoleFeature) {
            window.open(proLink, '_blank');
        }
        else
        {
            page = dest;
        }
    }
</script>

<div class="flex font-logo overflow-clip">
    <div class="bg-[#2D2D2D] shrink-0 text-[#A8A8A8] flex flex-col border-r-2 border-black" style="width: {collapsed ? "50px" : "260px"}; transition: width 0.1s;">
        <button class="flex justify-center items-center p-3 gap-2" onclick={toggle}>
            <img src="./icons/proxima_logo_32.png" class="w-[25px]" alt="">
            {#if !collapsed}
                <h1 class="text-xl bg-gradient-to-r from-[#f08521] to-white text-transparent bg-clip-text font-semibold font-logo w-full whitespace-nowrap">
                    Proxima Inspector
                </h1>
                <img src="./icons/play.png" class="rotate-180 w-[20px]" alt="">
            {/if}
        </button>
        <button class:selected={page === 'connection'} class="flex gap-1 p-3" onclick={() => page = 'connection'}>
            <img class="w-[30px]" src="./icons/connection.png" alt="">
            {#if !collapsed}
                <p class="text-lg">Connection</p>
            {/if}
        </button>
        <button class:disabled={!$selected} class:selected={page === 'inspector'} class="flex gap-1 p-3" onclick={() => page = 'inspector'}>
            <img class="w-[30px]" src="./icons/d_UnityEditor.SceneHierarchyWindow@2x.png" alt="">
            {#if !collapsed}
                <p class="text-lg">Inspector</p>
            {/if}
        </button>
        <button class:disabled={!$selected} class:selected={page === 'logs'} class="flex gap-1 p-3" onclick={() => page = 'logs'}>
            <img class="w-[30px]" src="./icons/d_UnityEditor.ConsoleWindow@2x.png" alt="">
            {#if !collapsed}
                <p class="text-lg">Logs</p>
            {/if}
        </button>
        <!-- <button class:disabled={!$selected} class:selected={page === 'profiler'} class="flex gap-1 p-3" on:click={() => goto('profiler')}>
            <img class="w-[30px]" src="./icons/performance_tracker_icon.png" alt="">
            {#if !collapsed}
            <div class="flex grow justify-between items-center">
                <p class="text-lg" class:disabled={!profilerFeature}>Profiler</p>
                {#if $selected && !profilerFeature}
                    <div class="text-xs py-1 px-2 ml-2 bg-[#191919] text-orange-300 font-bold font-logo rounded">Profiler Add-On</div>
                {/if}
            </div>
            {/if}
        </button> -->
        <button class:disabled={!$selected} class:selected={page === 'console'} class="flex gap-1 p-3 items-center" onclick={() => goto('console')}>
            <img class="w-[30px]" src="./icons/terminal.png" alt="">
            {#if !collapsed}
                <div class="flex grow justify-between items-center">
                    <p class="text-lg" class:disabled={!consoleFeature}>Console</p>
                    {#if $selected && !consoleFeature}
                        <div class="text-xs py-1 px-2 ml-2 bg-[#191919] text-orange-300 font-bold font-logo rounded">Upgrade to Pro</div>
                    {/if}
                </div>
            {/if}
        </button>
        <div class="grow"></div>
        <GameControl {collapsed} />
        <div class="pt-3"></div>
        <ConnectionStatus {collapsed}/>
        <div class="flex bg-[#191919] w-full border-t-[#2d2d2d] border-t-2 items-center">
            {#if collapsed}
                <div class="h-[28px]"></div>
            {:else}
                <a href="https://www.unityproxima.com" target="_blank" rel="noreferrer" class="text-sm hover:underline grow text-center hover:text-white border-[#292929] border-r-2 p-1">Website</a>
                <a href="https://www.unityproxima.com/docs" target="_blank" rel="noreferrer" class="text-sm hover:underline grow text-center hover:text-white border-[#292929] border-r-2 p-1">Docs</a>
                <a href="https://discord.gg/VM9cWJ9rjH" target="_blank" rel="noreferrer" class="text-sm hover:underline grow flex justify-center hover:text-white p-1"><img width="70px" src="./icons/discord.png" alt=""></a>
            {/if}
        </div>
    </div>
    <div class="grow h-screen flex text-[#A8A8A8] bg-[#2D2D2D] font-body border-[#191919]" style="max-width: calc(100% - {collapsed ? "50px" : "260px"});">
        {#if page === 'connection'}
            <ConnectPage />
        {:else if page === 'inspector'}
            <InspectorPage />
        {:else if page === 'logs'}
            <LogsPage />
        {:else if page === 'console'}
            <ConsolePage />
        {:else if page === 'profiler'}
            <ProfilerPage />
        {:else}
            <h1>Page not found</h1>
        {/if}
    </div>
</div>

<style>
    .selected {
        background-color: #191919;
    }

    .disabled {
        pointer-events: none;
        color: #4A4A4A;
    }
</style>